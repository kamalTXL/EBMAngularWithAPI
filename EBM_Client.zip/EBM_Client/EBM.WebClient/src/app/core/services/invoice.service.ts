import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from './api-config';
import { SalesDto } from '../models/models';

@Injectable({ providedIn: 'root' })
export class InvoiceService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<SalesDto[]> { return this.http.get<SalesDto[]>(`${API_BASE_URL}/invoices`); }
  get(no: string): Observable<SalesDto> { return this.http.get<SalesDto>(`${API_BASE_URL}/invoices/${no}`); }
  nextNumber(): Observable<{ invoiceNo: string }> { return this.http.get<{ invoiceNo: string }>(`${API_BASE_URL}/invoices/next-number`); }
  create(dto: SalesDto): Observable<SalesDto> { return this.http.post<SalesDto>(`${API_BASE_URL}/invoices`, dto); }
  update(no: string, dto: SalesDto): Observable<SalesDto> { return this.http.put<SalesDto>(`${API_BASE_URL}/invoices/${no}`, dto); }
  delete(no: string): Observable<void> { return this.http.delete<void>(`${API_BASE_URL}/invoices/${no}`); }
}
