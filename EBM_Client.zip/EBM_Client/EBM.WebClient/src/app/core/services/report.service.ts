import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from './api-config';
import { DashboardPointDto, ReportFilterDto, ReportRowDto } from '../models/models';

@Injectable({ providedIn: 'root' })
export class ReportService {
  constructor(private http: HttpClient) {}
  view(filter: ReportFilterDto): Observable<ReportRowDto[]> { return this.http.post<ReportRowDto[]>(`${API_BASE_URL}/report/view`, filter); }
  exportExcel(filter: ReportFilterDto): Observable<Blob> {
    return this.http.post(`${API_BASE_URL}/report/export-excel`, filter, { responseType: 'blob' });
  }
  dashboard(xAxis: string, series: string): Observable<DashboardPointDto[]> {
    return this.http.get<DashboardPointDto[]>(`${API_BASE_URL}/report/dashboard?xAxis=${xAxis}&series=${series}`);
  }
}
