import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { API_BASE_URL } from './api-config';

interface LoginResult { success: boolean; token?: string; message?: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  private tokenKey = 'A7f9c2D8e1B6xQ9vP4mK7zR3tY8uL2nW5sX6cJ1vB9dF3gH2kL8pQ';

  constructor(private http: HttpClient) {}

  login(userName: string, password: string): Observable<LoginResult> {
    return this.http.post<LoginResult>(`${API_BASE_URL}/auth/login`, { userName, password })
      .pipe(tap(r => { if (r.success && r.token) sessionStorage.setItem(this.tokenKey, r.token); }));
  }

  logout(): void { sessionStorage.removeItem(this.tokenKey); location.href = '/login'; }
  getToken(): string | null { return sessionStorage.getItem(this.tokenKey); }
  isLoggedIn(): boolean { return !!this.getToken(); }
}
