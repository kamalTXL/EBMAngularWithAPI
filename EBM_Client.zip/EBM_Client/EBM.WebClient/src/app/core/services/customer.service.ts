import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from './api-config';
import { CustomerDto, LookupDto } from '../models/models';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<CustomerDto[]> { return this.http.get<CustomerDto[]>(`${API_BASE_URL}/customers`); }
  get(code: string): Observable<CustomerDto> { return this.http.get<CustomerDto>(`${API_BASE_URL}/customers/${code}`); }
  create(dto: CustomerDto): Observable<CustomerDto> { return this.http.post<CustomerDto>(`${API_BASE_URL}/customers`, dto); }
  update(code: string, dto: CustomerDto): Observable<CustomerDto> { return this.http.put<CustomerDto>(`${API_BASE_URL}/customers/${code}`, dto); }
  delete(code: string): Observable<void> { return this.http.delete<void>(`${API_BASE_URL}/customers/${code}`); }
  areas(): Observable<LookupDto[]> { return this.http.get<LookupDto[]>(`${API_BASE_URL}/lookups/customer-areas`); }
  categories(): Observable<LookupDto[]> { return this.http.get<LookupDto[]>(`${API_BASE_URL}/lookups/customer-categories`); }
}
