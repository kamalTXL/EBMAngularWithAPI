import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from './api-config';
import { LookupDto, ProductDto } from '../models/models';

@Injectable({ providedIn: 'root' })
export class ProductService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<ProductDto[]> { return this.http.get<ProductDto[]>(`${API_BASE_URL}/products`); }
  get(code: string): Observable<ProductDto> { return this.http.get<ProductDto>(`${API_BASE_URL}/products/${code}`); }
  create(dto: ProductDto): Observable<ProductDto> { return this.http.post<ProductDto>(`${API_BASE_URL}/products`, dto); }
  update(code: string, dto: ProductDto): Observable<ProductDto> { return this.http.put<ProductDto>(`${API_BASE_URL}/products/${code}`, dto); }
  delete(code: string): Observable<void> { return this.http.delete<void>(`${API_BASE_URL}/products/${code}`); }
  categories(): Observable<LookupDto[]> { return this.http.get<LookupDto[]>(`${API_BASE_URL}/lookups/product-categories`); }
  brands(): Observable<LookupDto[]> { return this.http.get<LookupDto[]>(`${API_BASE_URL}/lookups/product-brands`); }
}
