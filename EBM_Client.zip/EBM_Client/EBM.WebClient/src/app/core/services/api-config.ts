// Same base URL is used regardless of which client hits the API - Web (Angular) or
// Desktop (WPF) - because both talk to the one shared ASP.NET Core Web API.
export const API_BASE_URL = 'https://localhost:5001/api';
