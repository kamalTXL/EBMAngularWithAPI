export interface LookupDto { code: string; name: string; }

export interface ProductDto {
  code: string; name: string; categoryCode: string; brandCode: string;
  imagePath?: string; salesRate: number; costRate: number;
}

export interface CustomerDto {
  code: string; name: string; address: string; areaCode: string; categoryCode: string;
}

export interface SalesDetailDto {
  id: number; invoiceNo: string; date: string; sno: number; stockCode: string;
  stockType: 'Stock' | 'NonStock'; quantity: number; rate: number; discount: number; amount: number;
}

export interface SalesDto {
  invoiceNo: string; date: string; customerCode: string; address: string;
  total: number; details: SalesDetailDto[];
}

export interface ReportFilterDto { from: string; to: string; level1?: string; level2?: string; }
export interface ReportRowDto {
  groupKey: string; groupLabel: string; subGroupKey?: string; subGroupLabel?: string;
  quantity: number; amount: number;
}
export interface DashboardPointDto { xAxis: string; seriesName: string; value: number; }
