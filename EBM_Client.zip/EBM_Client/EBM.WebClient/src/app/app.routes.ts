import { Routes } from '@angular/router';
import { authGuard } from './core/services/auth.guard';

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./features/login/login.component').then(m => m.LoginComponent) },
  {
    path: 'products', canActivate: [authGuard],
    loadComponent: () => import('./features/product-master/product-master.component').then(m => m.ProductMasterComponent)
  },
  {
    path: 'customers', canActivate: [authGuard],
    loadComponent: () => import('./features/customer-master/customer-master.component').then(m => m.CustomerMasterComponent)
  },
  {
    path: 'invoices', canActivate: [authGuard],
    loadComponent: () => import('./features/invoice/invoice.component').then(m => m.InvoiceComponent)
  },
  {
    path: 'report', canActivate: [authGuard],
    loadComponent: () => import('./features/report/report.component').then(m => m.ReportComponent)
  },
  {
    path: 'dashboard', canActivate: [authGuard],
    loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: '**', redirectTo: 'dashboard' }
];
