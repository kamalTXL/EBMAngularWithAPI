import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './core/services/auth.service';

// The Navigation Bar (Top/Bottom) icon-and-menu shell required by the spec:
// "All the forms should have a Navigation Bar (To navigate to Top/Bottom, Next/Prior, Find/Search)".
@Component({
  selector: 'ebm-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3" *ngIf="auth.isLoggedIn()">
      <a class="navbar-brand" routerLink="/dashboard">EBM Test Project</a>
      <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-sm btn-outline-light" routerLink="/dashboard">Dashboard</a>
        <a class="btn btn-sm btn-outline-light" routerLink="/products">Product Master</a>
        <a class="btn btn-sm btn-outline-light" routerLink="/customers">Customer Master</a>
        <a class="btn btn-sm btn-outline-light" routerLink="/invoices">Invoice</a>
        <a class="btn btn-sm btn-outline-light" routerLink="/report">Report</a>
        <button class="btn btn-sm btn-danger" (click)="auth.logout()">Logout</button>
      </div>
    </nav>
    <div class="container-fluid p-3">
      <router-outlet />
    </div>
  `
})
export class AppComponent {
  constructor(public auth: AuthService) {}
}
