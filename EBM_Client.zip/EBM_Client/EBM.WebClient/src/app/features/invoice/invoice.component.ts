import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InvoiceService } from '../../core/services/invoice.service';
import { ProductService } from '../../core/services/product.service';
import { CustomerService } from '../../core/services/customer.service';
import { CustomerDto, ProductDto, SalesDetailDto, SalesDto } from '../../core/models/models';

// Implements the Invoice transaction form: header (Invoice No/Date/Customer/Address),
// an editable grid with Stock/Non-Stock radio, Qty/Rate/Discount -> Amount, running
// Total footer, and New/Edit/Delete/Save/Cancel per the wireframe.
@Component({
  selector: 'ebm-invoice',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="card">
    <div class="card-header bg-dark text-white"><h5 class="m-0">Invoice</h5></div>
    <div class="card-body">
      <div class="d-flex form-toolbar gap-2 mb-3 flex-wrap">
        <button class="btn btn-outline-secondary" (click)="goto(0)" [disabled]="!invoices.length">|&lt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(index-1)" [disabled]="index<=0">&lt;&lt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(index+1)" [disabled]="index>=invoices.length-1">&gt;&gt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(invoices.length-1)" [disabled]="!invoices.length">&gt;|</button>
        <input class="form-control" style="max-width:220px" placeholder="Find invoice no..." [(ngModel)]="searchText" (ngModelChange)="search()">
      </div>

      <div class="row g-2 mb-2">
        <div class="col-md-3"><label class="form-label">Invoice No</label>
          <input class="form-control" [(ngModel)]="header.invoiceNo" [disabled]="true"></div>
        <div class="col-md-3"><label class="form-label">Date</label>
          <input type="date" class="form-control" [(ngModel)]="dateStr" [disabled]="!editable"></div>
        <div class="col-md-3"><label class="form-label">Customer</label>
          <select class="form-select" [(ngModel)]="header.customerCode" (ngModelChange)="onCustomerChange()" [disabled]="!editable">
            <option value="">-- select --</option>
            <option *ngFor="let c of customers" [value]="c.code">{{c.name}}</option>
          </select></div>
        <div class="col-md-3"><label class="form-label">Address</label>
          <input class="form-control" [(ngModel)]="header.address" [disabled]="!editable"></div>
      </div>

      <table class="table table-bordered grid-table align-middle">
        <thead class="table-light">
          <tr>
            <th>Sno</th><th>Stock/Non-Stock</th><th>Stock Code</th><th>Qty</th><th>Rate</th><th>Discount</th><th>Amount</th><th></th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let d of details; let i = index">
            <td>{{ i + 1 }}</td>
            <td>
              <select class="form-select" [(ngModel)]="d.stockType" [disabled]="!editable">
                <option value="Stock">Stock</option>
                <option value="NonStock">Non-Stock</option>
              </select>
            </td>
            <td>
              <select class="form-select" [(ngModel)]="d.stockCode" (ngModelChange)="onProductChange(d)" [disabled]="!editable || d.stockType==='NonStock'">
                <option value="">--</option>
                <option *ngFor="let p of products" [value]="p.code">{{p.name}}</option>
              </select>
            </td>
            <td><input type="number" class="form-control" [(ngModel)]="d.quantity" (ngModelChange)="recalc(d)" [disabled]="!editable"></td>
            <td><input type="number" class="form-control" [(ngModel)]="d.rate" (ngModelChange)="recalc(d)" [disabled]="!editable"></td>
            <td><input type="number" class="form-control" [(ngModel)]="d.discount" (ngModelChange)="recalc(d)" [disabled]="!editable"></td>
            <td class="text-end">{{ d.amount | number:'1.2-2' }}</td>
            <td><button class="btn btn-sm btn-outline-danger" (click)="removeLine(i)" [disabled]="!editable">x</button></td>
          </tr>
        </tbody>
      </table>
      <button class="btn btn-sm btn-outline-primary mb-3" (click)="addLine()" [disabled]="!editable">+ Add Line</button>

      <div class="text-end fw-bold fs-5">Total: {{ total | number:'1.2-2' }}</div>
      <div class="text-danger small mt-2" *ngIf="error">{{ error }}</div>

      <div class="d-flex form-toolbar gap-2 mt-3 flex-wrap">
        <button class="btn btn-success" (click)="newInvoice()">New</button>
        <button class="btn btn-primary" (click)="edit()" [disabled]="!header.invoiceNo">Edit</button>
        <button class="btn btn-danger" (click)="remove()" [disabled]="!header.invoiceNo">Delete</button>
        <div class="ms-auto d-flex gap-2">
          <button class="btn btn-primary" (click)="save()" [disabled]="!editable">Save</button>
          <button class="btn btn-secondary" (click)="cancel()">Cancel</button>
        </div>
      </div>
    </div>
  </div>
  `
})
export class InvoiceComponent implements OnInit {
  invoices: SalesDto[] = []; index = -1; editable = false; error = '';
  products: ProductDto[] = []; customers: CustomerDto[] = [];
  searchText = '';

  header: SalesDto = this.emptyHeader();
  details: SalesDetailDto[] = [];
  dateStr = new Date().toISOString().substring(0, 10);

  get total(): number { return this.details.reduce((s, d) => s + (d.amount || 0), 0); }

  constructor(private svc: InvoiceService, private productSvc: ProductService, private customerSvc: CustomerService) {}

  ngOnInit() {
    this.productSvc.getAll().subscribe(p => this.products = p);
    this.customerSvc.getAll().subscribe(c => this.customers = c);
    this.load();
  }

  emptyHeader(): SalesDto { return { invoiceNo: '', date: new Date().toISOString(), customerCode: '', address: '', total: 0, details: [] }; }

  load() {
    this.svc.getAll().subscribe(list => {
      this.invoices = list;
      if (list.length) this.goto(0); else this.newInvoice();
    });
  }

  search() {
    const t = this.searchText.toLowerCase();
    const found = this.invoices.findIndex(i => i.invoiceNo.toLowerCase().includes(t));
    if (found >= 0) this.goto(found);
  }

  goto(i: number) {
    if (i < 0 || i >= this.invoices.length) return;
    this.index = i;
    const inv = this.invoices[i];
    this.header = { ...inv }; this.details = inv.details.map(d => ({ ...d }));
    this.dateStr = inv.date.substring(0, 10); this.editable = false; this.error = '';
  }

  onCustomerChange() {
    const c = this.customers.find(c => c.code === this.header.customerCode);
    if (c) this.header.address = c.address;
  }

  onProductChange(d: SalesDetailDto) {
    const p = this.products.find(p => p.code === d.stockCode);
    if (p) { d.rate = p.salesRate; this.recalc(d); }
  }

  recalc(d: SalesDetailDto) { d.amount = Math.round(((d.quantity || 0) * (d.rate || 0) - (d.discount || 0)) * 100) / 100; }

  addLine() { this.details.push({ id: 0, invoiceNo: this.header.invoiceNo, date: this.dateStr, sno: this.details.length + 1, stockCode: '', stockType: 'Stock', quantity: 0, rate: 0, discount: 0, amount: 0 }); }
  removeLine(i: number) { this.details.splice(i, 1); }

  newInvoice() {
    this.svc.nextNumber().subscribe(r => {
      this.header = { ...this.emptyHeader(), invoiceNo: r.invoiceNo };
      this.details = []; this.dateStr = new Date().toISOString().substring(0, 10);
      this.editable = true; this.index = -1; this.error = '';
      this.addLine();
    });
  }

  edit() { this.editable = true; }

  save() {
    this.error = '';
    const payload: SalesDto = { ...this.header, date: this.dateStr, details: this.details };
    const isNew = this.index === -1;
    const req = isNew ? this.svc.create(payload) : this.svc.update(this.header.invoiceNo, payload);
    req.subscribe({ next: () => { this.editable = false; this.load(); },
                    error: e => this.error = e?.error?.message ?? 'Save failed.' });
  }

  remove() {
    if (!confirm(`Delete invoice ${this.header.invoiceNo}?`)) return;
    this.svc.delete(this.header.invoiceNo).subscribe({ next: () => this.load(),
      error: e => this.error = e?.error?.message ?? 'Delete failed.' });
  }

  cancel() { if (this.index >= 0) this.goto(this.index); else this.newInvoice(); }
}
