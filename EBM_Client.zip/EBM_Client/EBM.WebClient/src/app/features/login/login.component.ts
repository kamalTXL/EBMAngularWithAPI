import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

// Matches the Login wireframe: User Name / Password + disclaimer checkbox + Submit/Cancel.
@Component({
  selector: 'ebm-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="d-flex justify-content-center">
      <div class="card shadow-sm mt-5" style="max-width: 420px; width: 100%;">
        <div class="card-header bg-dark text-white text-center"><h4 class="m-0">Login</h4></div>
        <div class="card-body">
          <p class="small">Please enter below your User Name and Password, as per the email sent to you:</p>
          <div class="mb-2">
            <label class="form-label">User Name</label>
            <input class="form-control" [(ngModel)]="userName" name="userName">
          </div>
          <div class="mb-2">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" [(ngModel)]="password" name="password">
          </div>
          <div class="form-check my-2">
            <input class="form-check-input" type="checkbox" [(ngModel)]="accepted" name="accepted" id="accept">
            <label class="form-check-label small" for="accept">I have read the Instructions/Notes/Disclaimer as under, and understand &amp; accept the same.</label>
          </div>
          <div class="text-danger small" *ngIf="error">{{ error }}</div>
          <div class="d-flex gap-2 mt-3">
            <button class="btn btn-primary" [disabled]="!accepted || !userName || !password" (click)="submit()">Submit</button>
            <button class="btn btn-secondary" (click)="cancel()">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  userName = ''; password = ''; accepted = false; error = '';

  constructor(private auth: AuthService, private router: Router) {}

  submit() {
    this.auth.login(this.userName, this.password).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: err => this.error = err?.error?.message ?? 'Invalid user name or password.'
    });
  }

  cancel() { this.userName = ''; this.password = ''; this.accepted = false; }
}
