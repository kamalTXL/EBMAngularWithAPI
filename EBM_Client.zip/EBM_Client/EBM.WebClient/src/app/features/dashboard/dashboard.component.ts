import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../core/services/report.service';
import { DashboardPointDto } from '../../core/models/models';

// Implements the Dashboard wireframe requirement: at least one graph where the user
// can dynamically pick X and Y axis (drag-and-drop is approximated here with simple
// dropdowns bound to Item Groups, Customer Groups, Items, Customers, Periods) with
// live updating of data without manually refreshing the screen (auto re-fetches on change).
@Component({
  selector: 'ebm-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="card">
    <div class="card-header bg-dark text-white"><h5 class="m-0">Dashboard</h5></div>
    <div class="card-body">
      <div class="row g-2 mb-3">
        <div class="col-md-4">
          <label class="form-label">X Axis</label>
          <select class="form-select" [(ngModel)]="xAxis" (ngModelChange)="refresh()">
            <option *ngFor="let f of fields" [value]="f">{{ f }}</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Series / Group By</label>
          <select class="form-select" [(ngModel)]="series" (ngModelChange)="refresh()">
            <option *ngFor="let f of fields" [value]="f">{{ f }}</option>
          </select>
        </div>
      </div>

      <div class="border rounded p-3" style="min-height: 320px;">
        <div *ngFor="let group of grouped()" class="mb-2">
          <div class="d-flex justify-content-between small fw-bold"><span>{{ group.key }}</span><span>{{ group.total | number:'1.2-2' }}</span></div>
          <div class="progress" style="height: 18px;">
            <div class="progress-bar" [style.width.%]="group.pct"></div>
          </div>
        </div>
        <p class="text-muted" *ngIf="!points.length">No sales data yet for the selected grouping.</p>
      </div>
    </div>
  </div>
  `
})
export class DashboardComponent implements OnInit {
  fields = ['Customer', 'Area', 'Product', 'ProductCategory', 'ProductBrand'];
  xAxis = 'ProductCategory'; series = 'Product';
  points: DashboardPointDto[] = [];

  constructor(private svc: ReportService) {}
  ngOnInit() { this.refresh(); }

  refresh() { this.svc.dashboard(this.xAxis, this.series).subscribe(p => this.points = p); }

  grouped(): { key: string; total: number; pct: number }[] {
    const map = new Map<string, number>();
    for (const p of this.points) map.set(p.xAxis, (map.get(p.xAxis) ?? 0) + p.value);
    const max = Math.max(1, ...Array.from(map.values()));
    return Array.from(map.entries()).map(([key, total]) => ({ key, total, pct: (total / max) * 100 }));
  }
}
