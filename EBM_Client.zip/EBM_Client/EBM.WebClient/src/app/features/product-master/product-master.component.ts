import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../core/services/product.service';
import { LookupDto, ProductDto } from '../../core/models/models';

const EMPTY: ProductDto = { code: '', name: '', categoryCode: '', brandCode: '', imagePath: '', salesRate: 0, costRate: 0 };

// Implements the Product Master wireframe: First/Prev/Next/Last navigation bar with a
// Find/Search box, Code/Name/Category/Brand/Image/Sales Rate/Cost Rate fields, and
// New/Edit/Delete/Save/Cancel buttons.
@Component({
  selector: 'ebm-product-master',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="card">
    <div class="card-header bg-dark text-white"><h5 class="m-0">Product Master</h5></div>
    <div class="card-body">
      <div class="d-flex form-toolbar gap-2 mb-3 flex-wrap">
        <button class="btn btn-outline-secondary" (click)="goto(0)" [disabled]="!items.length">|&lt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(index-1)" [disabled]="index<=0">&lt;&lt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(index+1)" [disabled]="index>=items.length-1">&gt;&gt;</button>
        <button class="btn btn-outline-secondary" (click)="goto(items.length-1)" [disabled]="!items.length">&gt;|</button>
        <input class="form-control" style="max-width:220px" placeholder="Find/Search..." [(ngModel)]="searchText" (ngModelChange)="search()">
      </div>

      <div class="row g-2">
        <div class="col-md-3"><label class="form-label">Code</label>
          <input class="form-control" [(ngModel)]="current.code" [disabled]="!isNew && !editing"></div>
        <div class="col-md-9"><label class="form-label">Name</label>
          <input class="form-control" [(ngModel)]="current.name" [disabled]="!editing && !isNew"></div>

        <div class="col-md-6"><label class="form-label">Category</label>
          <select class="form-select" [(ngModel)]="current.categoryCode" [disabled]="!editing && !isNew">
            <option *ngFor="let c of categories" [value]="c.code">{{c.name}}</option>
          </select></div>
        <div class="col-md-6"><label class="form-label">Brand</label>
          <select class="form-select" [(ngModel)]="current.brandCode" [disabled]="!editing && !isNew">
            <option *ngFor="let b of brands" [value]="b.code">{{b.name}}</option>
          </select></div>

        <div class="col-md-8"><label class="form-label">Image</label>
          <input class="form-control" [(ngModel)]="current.imagePath" placeholder="path or URL" [disabled]="!editing && !isNew"></div>

        <div class="col-md-6"><label class="form-label">Sales Rate</label>
          <input type="number" step="0.001" class="form-control" [(ngModel)]="current.salesRate" [disabled]="!editing && !isNew"></div>
        <div class="col-md-6"><label class="form-label">Cost Rate</label>
          <input type="number" step="0.001" class="form-control" [(ngModel)]="current.costRate" [disabled]="!editing && !isNew"></div>
      </div>

      <div class="text-danger small mt-2" *ngIf="error">{{ error }}</div>

      <div class="d-flex form-toolbar gap-2 mt-3 flex-wrap">
        <button class="btn btn-success" (click)="newRecord()">New</button>
        <button class="btn btn-primary" (click)="edit()" [disabled]="!current.code">Edit</button>
        <button class="btn btn-danger" (click)="remove()" [disabled]="!current.code">Delete</button>
        <div class="ms-auto d-flex gap-2">
          <button class="btn btn-primary" (click)="save()" [disabled]="!editing && !isNew">Save</button>
          <button class="btn btn-secondary" (click)="cancel()">Cancel</button>
        </div>
      </div>
    </div>
  </div>
  `
})
export class ProductMasterComponent implements OnInit {
  items: ProductDto[] = []; filtered: ProductDto[] = [];
  categories: LookupDto[] = []; brands: LookupDto[] = [];
  current: ProductDto = { ...EMPTY };
  index = -1; editing = false; isNew = false; searchText = ''; error = '';

  constructor(private svc: ProductService) {}

  ngOnInit() {
    this.svc.categories().subscribe(c => this.categories = c);
    this.svc.brands().subscribe(b => this.brands = b);
    this.load();
  }

  load() {
    this.svc.getAll().subscribe(items => {
      this.items = items; this.filtered = items;
      if (items.length) this.goto(0); else { this.current = { ...EMPTY }; this.index = -1; }
    });
  }

  search() {
    const t = this.searchText.toLowerCase();
    this.filtered = this.items.filter(p => p.code.toLowerCase().includes(t) || p.name.toLowerCase().includes(t));
    if (this.filtered.length) this.goto(0);
  }

  goto(i: number) {
    if (i < 0 || i >= this.filtered.length) return;
    this.index = i; this.current = { ...this.filtered[i] }; this.editing = false; this.isNew = false; this.error = '';
  }

  newRecord() { this.current = { ...EMPTY }; this.isNew = true; this.editing = false; this.error = ''; }
  edit() { this.editing = true; this.isNew = false; }

  save() {
    this.error = '';
    const req = this.isNew ? this.svc.create(this.current) : this.svc.update(this.current.code, this.current);
    req.subscribe({ next: () => { this.editing = false; this.isNew = false; this.load(); },
                    error: e => this.error = e?.error?.message ?? 'Save failed.' });
  }

  remove() {
    if (!confirm(`Delete product ${this.current.code}?`)) return;
    this.svc.delete(this.current.code).subscribe({ next: () => this.load(),
      error: e => this.error = e?.error?.message ?? 'Delete failed.' });
  }

  cancel() { if (this.index >= 0) this.goto(this.index); else this.current = { ...EMPTY }; this.editing = false; this.isNew = false; this.error=''; }
}
