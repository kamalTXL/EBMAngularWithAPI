import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../core/services/report.service';
import { ReportRowDto } from '../../core/models/models';

// Implements the Report screen wireframe: Date Range (From/To) + up to 2 grouping
// levels + View / Print / Export to Excel. (Print uses the browser's native print dialog.)
@Component({
  selector: 'ebm-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="card">
    <div class="card-header bg-dark text-white"><h5 class="m-0">Report</h5></div>
    <div class="card-body">
      <div class="row g-2">
        <div class="col-md-3"><label class="form-label">From</label>
          <input type="date" class="form-control" [(ngModel)]="from"></div>
        <div class="col-md-3"><label class="form-label">To</label>
          <input type="date" class="form-control" [(ngModel)]="to"></div>
        <div class="col-md-3"><label class="form-label">Grouping Level 1</label>
          <select class="form-select" [(ngModel)]="level1">
            <option *ngFor="let l of levels" [value]="l">{{ l }}</option>
          </select></div>
        <div class="col-md-3"><label class="form-label">Grouping Level 2</label>
          <select class="form-select" [(ngModel)]="level2">
            <option value="">(none)</option>
            <option *ngFor="let l of levels" [value]="l">{{ l }}</option>
          </select></div>
      </div>

      <div class="d-flex form-toolbar gap-2 my-3">
        <button class="btn btn-primary" (click)="view()">View</button>
        <button class="btn btn-outline-secondary" (click)="print()">Print</button>
        <button class="btn btn-success" (click)="exportExcel()">Export To Excel</button>
      </div>

      <table class="table table-bordered" *ngIf="rows.length">
        <thead class="table-light">
          <tr><th>{{level1}}</th><th *ngIf="level2">{{level2}}</th><th class="text-end">Quantity</th><th class="text-end">Amount</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of rows">
            <td>{{ r.groupLabel }}</td>
            <td *ngIf="level2">{{ r.subGroupLabel }}</td>
            <td class="text-end">{{ r.quantity | number:'1.0-3' }}</td>
            <td class="text-end">{{ r.amount | number:'1.2-2' }}</td>
          </tr>
        </tbody>
        <tfoot>
          <tr class="fw-bold">
            <td [attr.colspan]="level2 ? 2 : 1">Grand Total</td>
            <td class="text-end">{{ totalQty | number:'1.0-3' }}</td>
            <td class="text-end">{{ totalAmt | number:'1.2-2' }}</td>
          </tr>
        </tfoot>
      </table>
      <p class="text-muted" *ngIf="!rows.length">No data. Click View to run the report.</p>
    </div>
  </div>
  `
})
export class ReportComponent {
  levels = ['Customer', 'Area', 'Product', 'ProductCategory', 'ProductBrand'];
  level1 = 'Product'; level2 = '';
  from = new Date(new Date().setDate(1)).toISOString().substring(0, 10);
  to = new Date().toISOString().substring(0, 10);
  rows: ReportRowDto[] = [];

  get totalQty() { return this.rows.reduce((s, r) => s + r.quantity, 0); }
  get totalAmt() { return this.rows.reduce((s, r) => s + r.amount, 0); }

  constructor(private svc: ReportService) {}

  view() {
    this.svc.view({ from: this.from, to: this.to, level1: this.level1, level2: this.level2 || undefined })
      .subscribe(r => this.rows = r);
  }

  print() { window.print(); }

  exportExcel() {
    this.svc.exportExcel({ from: this.from, to: this.to, level1: this.level1, level2: this.level2 || undefined })
      .subscribe(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `SalesReport_${this.from}_${this.to}.xlsx`; a.click();
        window.URL.revokeObjectURL(url);
      });
  }
}
