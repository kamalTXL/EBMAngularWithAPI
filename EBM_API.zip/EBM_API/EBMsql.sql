CREATE TABLE ProductCategory (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL
);

CREATE TABLE ProductBrand (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL
);
CREATE TABLE Product (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(150) NOT NULL,
    CategoryCode VARCHAR(10) NOT NULL,
    BrandCode VARCHAR(10) NOT NULL,
    SalesRate DECIMAL(18,3) NOT NULL,
    CostRate DECIMAL(18,3) NOT NULL,

    CONSTRAINT FK_Product_Category
        FOREIGN KEY (CategoryCode) REFERENCES ProductCategory(Code),

    CONSTRAINT FK_Product_Brand
        FOREIGN KEY (BrandCode) REFERENCES ProductBrand(Code)
);
CREATE TABLE CustomerCategory (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL
);
CREATE TABLE CustomerArea (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL
);

CREATE TABLE Customer (
    Code VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(150) NOT NULL,
    Address VARCHAR(250) NULL,
    AreaCode VARCHAR(10) NOT NULL,
    CategoryCode VARCHAR(10) NOT NULL,

    CONSTRAINT FK_Customer_Area
        FOREIGN KEY (AreaCode) REFERENCES CustomerArea(Code),

    CONSTRAINT FK_Customer_Category
        FOREIGN KEY (CategoryCode) REFERENCES CustomerCategory(Code)
);
CREATE INDEX IX_Product_CategoryCode ON Product(CategoryCode);
CREATE INDEX IX_Product_BrandCode ON Product(BrandCode);
CREATE INDEX IX_Customer_AreaCode ON Customer(AreaCode);
CREATE INDEX IX_Customer_CategoryCode ON Customer(CategoryCode);
INSERT INTO ProductCategory (Code, Name) VALUES ('CAT01','Electronics'), ('CAT02','Groceries');
INSERT INTO ProductBrand (Code, Name) VALUES ('BR01','Samsung'), ('BR02','Nestle');
INSERT INTO Product (Code, Name, CategoryCode, BrandCode, SalesRate, CostRate) VALUES
  ('P001','Galaxy Charger','CAT01','BR01',25.000,15.000),
  ('P002','Nescafe 200g','CAT02','BR02',12.500,8.000);

INSERT INTO CustomerCategory (Code, Name) VALUES ('CC01','Retail'), ('CC02','Wholesale');
INSERT INTO CustomerArea (Code, Name) VALUES ('AR01','Deira'), ('AR02','Bur Dubai');
INSERT INTO Customer (Code, Name, Address, AreaCode, CategoryCode) VALUES
  ('C001','Al Futtaim Trading','Deira, Dubai','AR01','CC01'),
  ('C002','Landmark Group','Bur Dubai','AR02','CC02');
  CREATE TABLE [Users] (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    PasswordSalt NVARCHAR(255) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

INSERT INTO [Users] (Name, PasswordHash, PasswordSalt, IsActive)
VALUES 
('admin', 'admin123', 'SALT_1', 1),
('john.doe', 'admin123', 'SALT_2', 1),
('test.user', 'admin123', 'SALT_3', 0);
