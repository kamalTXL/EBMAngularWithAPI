# EBM Test Project

A full implementation of the EBM test-project spec: Product Master, Customer Master,
Invoice, Report, and Dashboard, built as a real 3-tier solution on **ASP.NET Core Web
API + Angular**, with the Angular app also packaged as a native desktop app (Electron)
so there's a browser front end and a Windows/Mac/Linux desktop front end sharing the
exact same UI code and the exact same backend.

## Architecture (3-tier, one UI codebase, two shells)

```
┌────────────────────────┐        ┌───────────────────────────┐
│  Browser                │        │  EBM.DesktopShell           │
│  (EBM.WebClient/Angular)│        │  (Electron - same Angular   │
│                          │        │   build, native window)    │
└───────────┬──────────────┘        └────────────┬────────────────┘
            │        HTTPS + JWT bearer token     │
            └────────────────┬─────────────────────┘
                              ▼
                    ┌───────────────────────┐
                    │  EBM.WebAPI            │   <- Presentation-agnostic API,
                    │  (ASP.NET Core)        │      identical for both shells
                    └───────────┬────────────┘
                                ▼
                    ┌───────────────────────┐
                    │  EBM.BusinessLogic     │   <- ALL business rules live here
                    │  (services, DTOs)      │      (validation, totals, reports)
                    └───────────┬────────────┘
                                ▼
                    ┌───────────────────────┐
                    │  EBM.DataAccess        │   <- EF Core (Repository + UnitOfWork)
                    │  (DbContext, EF Core)  │
                    └───────────┬────────────┘
                                ▼
                    ┌───────────────────────┐
                    │  SQL Server            │
                    └───────────────────────┘
                                ▲
                    ┌───────────────────────┐
                    │  EBM.Domain            │   <- POCO entities, shared by
                    │  (entities, enums)     │      DataAccess + BusinessLogic
                    └───────────────────────┘
```

This satisfies the spec's technical requirements directly:
- **.NET Core / EF Core / SQL Server** — `EBM.DataAccess`.
- **3-tier, UI / business logic / DB separate** — `EBM.WebAPI` (UI-facing only) never
  touches EF Core; `EBM.BusinessLogic` never renders anything; `EBM.DataAccess` never
  contains business rules.
- **Dual front end, same business logic & backend API** — the browser (`EBM.WebClient`)
  and the desktop app (`EBM.DesktopShell`) are literally the same Angular build,
  wrapped either by a browser tab or by an Electron `BrowserWindow`. Both are pure
  REST/JSON consumers of the one `EBM.WebAPI`; there is exactly one UI codebase and
  exactly one implementation of every business rule (totals, validation, numbering,
  reporting) — no duplication to keep in sync between "web" and "desktop".

## Project map

| Project | Purpose |
|---|---|
| `src/EBM.Domain` | POCO entities matching the Database Table Diagram (User, ProductCategory, ProductBrand, Product, CustomerCategory, CustomerArea, Customer, Sales, SalesDetail). |
| `src/EBM.DataAccess` | `EBMDbContext` (EF Core + SQL Server), generic `Repository<T>` + `UnitOfWork`. |
| `src/EBM.BusinessLogic` | Services: `AuthService` (hashed login), `MasterDataService` (Product/Customer Master CRUD), `InvoiceService` (server-side line/total recalculation, invoice numbering), `ReportService` (grouped report + Excel export via ClosedXML, dashboard data). |
| `src/EBM.WebAPI` | ASP.NET Core Web API, JWT auth, Swagger. Controllers: Auth, Lookups, Products, Customers, Invoices, Report. |

| `src/EBM.WebClient` | Angular 17 standalone-components app: Login, Product Master, Customer Master, Invoice, Report, Dashboard — Bootstrap-based, responsive. This is the ONLY UI codebase. |
| `src/EBM.DesktopShell` | Electron wrapper - loads the exact same Angular build in a native window. No separate UI code, no separate business logic. |
| `database/seed-data.sql` | Optional sample lookup/master data. |

## Prerequisites

- .NET 8 SDK
- Node.js 18+ and npm (for the Angular client)
- SQL Server (local, container, or Azure SQL)
- Electron desktop shell runs on Windows, macOS, and Linux (it's just Chromium + Node, no OS-specific UI code)

## Setup

### 1. Database

```bash
cd src/EBM.WebAPI
dotnet tool install --global dotnet-ef   # once
dotnet ef migrations add InitialCreate --project ../EBM.DataAccess --startup-project .
dotnet ef database update --project ../EBM.DataAccess --startup-project .
```

Update the connection string in `src/EBM.WebAPI/appsettings.json` first if your SQL
Server instance isn't the local default.

Optionally load `database/seed-data.sql` for sample Product/Customer master data.

### 2. Create the first login user

With the API running (Development environment) and no users in the database yet, call
the one-time bootstrap endpoint:

```bash
curl -k -X POST https://localhost:5001/api/auth/setup \
  -H "Content-Type: application/json" \
  -d "{\"userName\":\"admin\",\"password\":\"YourPassword123!\"}"
```

or from Swagger UI (`/swagger`) → `Auth` → `POST /api/auth/setup` → Try it out.

This creates the user with a correctly PBKDF2-hashed password (same algorithm
`AuthService.LoginAsync` verifies against), so the Login screen works immediately
afterward. The endpoint is self-disarming:
- it 404s unless `ASPNETCORE_ENVIRONMENT=Development` (the default for `dotnet run`)
- it refuses (409) once any user already exists

So once you've created your admin user, calling it again does nothing — no need to
manually delete the endpoint before sharing/deploying, though removing
`AuthController.Setup` entirely is still the cleanest thing to do before a real deployment.

### 3. Run the Web API (shared backend)

```bash
cd src/EBM.WebAPI
dotnet run
```

Swagger UI: `https://localhost:5001/swagger` — **note there is nothing mapped at the
bare root `/`**, so browsing to `https://localhost:5001/` (or whatever port `dotnet run`
prints) will 404; that's expected. Go to `/swagger` or one of the `/api/...` routes.

A `Properties/launchSettings.json` pins Kestrel to `http://localhost:5000` /
`https://localhost:5001` so it matches the URLs hardcoded in the Angular client
(`api-config.ts`); the Electron shell (`EBM.DesktopShell`) loads the Angular app itself so it inherits the same config. If you ever see the API start
on a different, random-looking port (e.g. `:49827`), it means `launchSettings.json`
was ignored (common if you run `dotnet EBM.WebAPI.dll` directly, or launch via IIS
Express) — either force the profile with `dotnet run --launch-profile https`, or
update both client configs to whatever port it actually bound to.

### 4. Run the Angular web client

```bash
cd src/EBM.WebClient
npm install
npm start
```

Open `http://localhost:4200`. Update `src/app/core/services/api-config.ts` if your
API runs on a different port.

### 5. Run the desktop shell (Electron - Windows/Mac/Linux)

Dev mode (loads `http://localhost:4200`, so start the Angular dev server first — step 4 above):

```bash
cd src/EBM.DesktopShell
npm install
npm run start:dev
```

Packaged mode (builds the Angular app once, then loads the static build directly with
no `ng serve` needed):

```bash
cd src/EBM.DesktopShell
npm install
npm run pack     # builds EBM.WebClient, then stages an unpacked Electron app in ./release
npm start        # or: npm run dist, to produce a real installer (.exe/.dmg/.AppImage)
```

There is no separate desktop UI code or desktop-specific business logic to keep in
sync — `EBM.DesktopShell/main.js` just opens a `BrowserWindow` pointed at the same
Angular files/dev-server used by the browser, which call the same `EBM.WebAPI`.

## Feature coverage vs. the spec

- **Login** — user name/password + disclaimer checkbox, both clients.
- **Product Master / Customer Master** — Code/Name/Category/Brand (or Area) fields,
  First/Prev/Next/Last navigation, Find/Search, New/Edit/Delete/Save/Cancel — both clients.
- **Invoice** — header + editable line grid (Stock/Non-Stock, Qty/Rate/Discount →
  Amount), running Total, server recalculates every amount and the grand total so the
  client can never submit a tampered total.
- **Report** — date range, two grouping levels (Customer/Area/Product/Category/Brand),
  View, Print (native browser print, in both the browser tab and the Electron window), Export to Excel (ClosedXML-generated
  `.xlsx`, formatted with sub-totals per the sample in the PDF).
- **Dashboard** — chart with selectable X-axis/series (Item Groups, Customer Groups,
  Items, Customers, Periods), refreshes automatically on selection change.

## Known gaps / next steps (given the scope of a 20–40 hour spec)

- Email-the-report (To/Cc/Bcc/Subject/Body, PDF attachment) is stubbed out in
  `InvoicesController` as a comment — wire up `System.Net.Mail` or a transactional
  email API plus a PDF renderer (e.g. QuestPDF) to complete it.
- Advanced grid features (column resize/drag/group like DevExpress/Telerik) are
  implemented with plain HTML tables rather than a commercial grid
  control, since none is licensed here — swap in DevExpress/Telerik components and
  the underlying API contracts stay the same.
- Product image upload is a text `ImagePath` field rather than a file-upload widget;
  add a `POST /api/products/{code}/image` endpoint plus blob storage to finish it.
- No automated tests are included; the layering (Domain/DataAccess/BusinessLogic/API)
  is structured specifically to make unit-testing `EBM.BusinessLogic` straightforward
  once you add a test project referencing it with a mocked `IUnitOfWork`.

## A note on this environment

This code was written and reviewed for structure and TypeScript syntax, but this
sandbox has no .NET SDK and no access to NuGet, so the C# projects could not be
`dotnet build`'d here. Please run `dotnet build` on your machine as a first step —
happy to fix up any compiler errors that turn up.
