namespace EBM.DesktopClient.Models;

// Mirrors EBM.BusinessLogic.DTOs exactly - the WPF client is a pure REST consumer of
// EBM.WebAPI, so it intentionally does NOT reference EF Core, the DataAccess project,
// or the Domain project directly. That keeps the "same business logic / back-end for
// both front ends" requirement honest: all real logic lives in the Web API only.
public record LookupDto(string Code, string Name);

public record LoginRequest(string UserName, string Password);
public record LoginResult(bool Success, string? Token, string? Message);

public record ProductDto(
    string Code, string Name, string CategoryCode, string BrandCode,
    string? ImagePath, decimal SalesRate, decimal CostRate);

public record CustomerDto(
    string Code, string Name, string Address, string AreaCode, string CategoryCode);

public record SalesDetailDto(
    int Id, string InvoiceNo, DateTime Date, int Sno, string StockCode,
    string StockType, decimal Quantity, decimal Rate, decimal Discount, decimal Amount);

public record SalesDto(
    string InvoiceNo, DateTime Date, string CustomerCode, string Address,
    decimal Total, List<SalesDetailDto> Details);

public record ReportFilterDto(DateTime From, DateTime To, string? Level1, string? Level2);
public record ReportRowDto(string GroupKey, string GroupLabel, string? SubGroupKey, string? SubGroupLabel, decimal Quantity, decimal Amount);
