using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using EBM.DesktopClient.Models;

namespace EBM.DesktopClient.Services;

// Single HttpClient wrapper the entire WPF app shares - talks to the SAME EBM.WebAPI
// base URL and endpoints as the Angular web client (see EBM.WebClient/.../api-config.ts).
public class ApiClient
{
    private const string BaseUrl = "https://localhost:5001/api";
    private readonly HttpClient _http = new() { BaseAddress = new Uri(BaseUrl) };

    public static ApiClient Instance { get; } = new();

    public string? Token { get; private set; }

    public void SetToken(string token)
    {
        Token = token;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public async Task<LoginResult?> LoginAsync(string userName, string password)
    {
        var resp = await _http.PostAsJsonAsync("auth/login", new LoginRequest(userName, password));
        var result = await resp.Content.ReadFromJsonAsync<LoginResult>();
        if (resp.IsSuccessStatusCode && result?.Token is not null) SetToken(result.Token);
        return result;
    }

    public Task<List<LookupDto>?> GetProductCategoriesAsync() => _http.GetFromJsonAsync<List<LookupDto>>("lookups/product-categories");
    public Task<List<LookupDto>?> GetProductBrandsAsync() => _http.GetFromJsonAsync<List<LookupDto>>("lookups/product-brands");
    public Task<List<LookupDto>?> GetCustomerAreasAsync() => _http.GetFromJsonAsync<List<LookupDto>>("lookups/customer-areas");
    public Task<List<LookupDto>?> GetCustomerCategoriesAsync() => _http.GetFromJsonAsync<List<LookupDto>>("lookups/customer-categories");

    public Task<List<ProductDto>?> GetProductsAsync() => _http.GetFromJsonAsync<List<ProductDto>>("products");
    public Task<HttpResponseMessage> CreateProductAsync(ProductDto dto) => _http.PostAsJsonAsync("products", dto);
    public Task<HttpResponseMessage> UpdateProductAsync(string code, ProductDto dto) => _http.PutAsJsonAsync($"products/{code}", dto);
    public Task<HttpResponseMessage> DeleteProductAsync(string code) => _http.DeleteAsync($"products/{code}");

    public Task<List<CustomerDto>?> GetCustomersAsync() => _http.GetFromJsonAsync<List<CustomerDto>>("customers");
    public Task<HttpResponseMessage> CreateCustomerAsync(CustomerDto dto) => _http.PostAsJsonAsync("customers", dto);
    public Task<HttpResponseMessage> UpdateCustomerAsync(string code, CustomerDto dto) => _http.PutAsJsonAsync($"customers/{code}", dto);
    public Task<HttpResponseMessage> DeleteCustomerAsync(string code) => _http.DeleteAsync($"customers/{code}");

    public Task<List<SalesDto>?> GetInvoicesAsync() => _http.GetFromJsonAsync<List<SalesDto>>("invoices");
    public async Task<string> NextInvoiceNoAsync()
    {
        var r = await _http.GetFromJsonAsync<Dictionary<string, string>>("invoices/next-number");
        return r?["invoiceNo"] ?? "000001";
    }
    public Task<HttpResponseMessage> CreateInvoiceAsync(SalesDto dto) => _http.PostAsJsonAsync("invoices", dto);
    public Task<HttpResponseMessage> UpdateInvoiceAsync(string no, SalesDto dto) => _http.PutAsJsonAsync($"invoices/{no}", dto);
    public Task<HttpResponseMessage> DeleteInvoiceAsync(string no) => _http.DeleteAsync($"invoices/{no}");

    public async Task<List<ReportRowDto>?> ViewReportAsync(ReportFilterDto filter)
    {
        var resp = await _http.PostAsJsonAsync("report/view", filter);
        return await resp.Content.ReadFromJsonAsync<List<ReportRowDto>>();
    }

    public async Task<byte[]> ExportExcelAsync(ReportFilterDto filter)
    {
        var resp = await _http.PostAsJsonAsync("report/export-excel", filter);
        return await resp.Content.ReadAsByteArrayAsync();
    }
}
