using System.Windows;

namespace EBM.DesktopClient.Views;

public partial class MainShellWindow : Window
{
    public MainShellWindow() => InitializeComponent();

    private void OpenProductMaster_Click(object sender, RoutedEventArgs e) => new ProductMasterWindow().Show();
    private void OpenCustomerMaster_Click(object sender, RoutedEventArgs e) => new CustomerMasterWindow().Show();
    private void OpenInvoice_Click(object sender, RoutedEventArgs e) => new InvoiceWindow().Show();
    private void OpenReport_Click(object sender, RoutedEventArgs e) => new ReportWindow().Show();

    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        new LoginWindow().Show();
        Close();
    }
}
