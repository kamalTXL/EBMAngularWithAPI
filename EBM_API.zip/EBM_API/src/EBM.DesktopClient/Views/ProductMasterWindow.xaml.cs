using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using EBM.DesktopClient.Models;
using EBM.DesktopClient.Services;

namespace EBM.DesktopClient.Views;

// WPF equivalent of the Angular ProductMasterComponent - same fields, same
// New/Edit/Delete/Save/Cancel + navigation behavior, same EBM.WebAPI endpoints.
public partial class ProductMasterWindow : Window
{
    private List<ProductDto> _items = new();
    private List<ProductDto> _filtered = new();
    private int _index = -1;
    private bool _editing;
    private bool _isNew;

    public ProductMasterWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await LoadAsync();
    }

    private async System.Threading.Tasks.Task LoadAsync()
    {
        CategoryCombo.ItemsSource = await ApiClient.Instance.GetProductCategoriesAsync();
        BrandCombo.ItemsSource = await ApiClient.Instance.GetProductBrandsAsync();
        _items = await ApiClient.Instance.GetProductsAsync() ?? new();
        _filtered = _items;
        if (_filtered.Count > 0) GoTo(0); else ClearForm();
    }

    private void SetEnabled(bool enabled)
    {
        NameBox.IsEnabled = enabled; CategoryCombo.IsEnabled = enabled; BrandCombo.IsEnabled = enabled;
        SalesRateBox.IsEnabled = enabled; CostRateBox.IsEnabled = enabled;
        CodeBox.IsEnabled = _isNew;
    }

    private void GoTo(int i)
    {
        if (i < 0 || i >= _filtered.Count) return;
        _index = i; _editing = false; _isNew = false;
        var p = _filtered[i];
        CodeBox.Text = p.Code; NameBox.Text = p.Name;
        CategoryCombo.SelectedValue = p.CategoryCode; BrandCombo.SelectedValue = p.BrandCode;
        SalesRateBox.Text = p.SalesRate.ToString(); CostRateBox.Text = p.CostRate.ToString();
        SetEnabled(false); ErrorText.Text = "";
    }

    private void ClearForm()
    {
        _index = -1;
        CodeBox.Text = NameBox.Text = SalesRateBox.Text = CostRateBox.Text = "";
        CategoryCombo.SelectedIndex = -1; BrandCombo.SelectedIndex = -1;
    }

    private void First_Click(object sender, RoutedEventArgs e) => GoTo(0);
    private void Prev_Click(object sender, RoutedEventArgs e) => GoTo(_index - 1);
    private void Next_Click(object sender, RoutedEventArgs e) => GoTo(_index + 1);
    private void Last_Click(object sender, RoutedEventArgs e) => GoTo(_filtered.Count - 1);

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var t = SearchBox.Text.ToLowerInvariant();
        _filtered = _items.Where(p => p.Code.ToLowerInvariant().Contains(t) || p.Name.ToLowerInvariant().Contains(t)).ToList();
        if (_filtered.Count > 0) GoTo(0);
    }

    private void New_Click(object sender, RoutedEventArgs e)
    {
        ClearForm(); _isNew = true; _editing = false; SetEnabled(true); ErrorText.Text = "";
    }

    private void Edit_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(CodeBox.Text)) return;
        _editing = true; _isNew = false; SetEnabled(true);
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = "";
        if (!decimal.TryParse(SalesRateBox.Text, out var sr) || !decimal.TryParse(CostRateBox.Text, out var cr))
        {
            ErrorText.Text = "Sales Rate / Cost Rate must be numeric.";
            return;
        }

        var dto = new ProductDto(CodeBox.Text, NameBox.Text,
            (string)CategoryCombo.SelectedValue, (string)BrandCombo.SelectedValue, null, sr, cr);

        var resp = _isNew
            ? await ApiClient.Instance.CreateProductAsync(dto)
            : await ApiClient.Instance.UpdateProductAsync(dto.Code, dto);

        if (resp.IsSuccessStatusCode) { await LoadAsync(); }
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(CodeBox.Text)) return;
        if (MessageBox.Show($"Delete product {CodeBox.Text}?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        var resp = await ApiClient.Instance.DeleteProductAsync(CodeBox.Text);
        if (resp.IsSuccessStatusCode) await LoadAsync();
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        if (_index >= 0) GoTo(_index); else ClearForm();
        SetEnabled(false); _editing = false; _isNew = false; ErrorText.Text = "";
    }
}
