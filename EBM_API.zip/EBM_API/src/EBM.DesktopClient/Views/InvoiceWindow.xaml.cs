using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using EBM.DesktopClient.Models;
using EBM.DesktopClient.Services;

namespace EBM.DesktopClient.Views;

// WPF equivalent of the Angular InvoiceComponent - editable line grid, Stock/Non-Stock,
// running total, and the same New/Edit/Delete/Save/Cancel workflow against EBM.WebAPI.
public partial class InvoiceWindow : Window
{
    private List<SalesDto> _invoices = new();
    private List<CustomerDto> _customers = new();
    private int _index = -1;
    private bool _isNew;
    public ObservableCollection<LineVm> Lines { get; } = new();

    public InvoiceWindow()
    {
        InitializeComponent();
        LinesGrid.ItemsSource = Lines;
        Loaded += async (_, _) => await LoadAsync();
    }

    private async System.Threading.Tasks.Task LoadAsync()
    {
        _customers = await ApiClient.Instance.GetCustomersAsync() ?? new();
        CustomerCombo.ItemsSource = _customers;
        _invoices = await ApiClient.Instance.GetInvoicesAsync() ?? new();
        if (_invoices.Count > 0) GoTo(0); else await NewInvoiceAsync();
    }

    private void SetEnabled(bool enabled)
    {
        DatePickerBox.IsEnabled = enabled; CustomerCombo.IsEnabled = enabled; LinesGrid.IsEnabled = enabled;
    }

    private void GoTo(int i)
    {
        if (i < 0 || i >= _invoices.Count) return;
        _index = i; _isNew = false;
        var inv = _invoices[i];
        InvoiceNoBox.Text = inv.InvoiceNo; DatePickerBox.SelectedDate = inv.Date;
        CustomerCombo.SelectedValue = inv.CustomerCode;
        Lines.Clear();
        foreach (var d in inv.Details) Lines.Add(LineVm.From(d));
        UpdateTotal(); SetEnabled(false); ErrorText.Text = "";
    }

    private async System.Threading.Tasks.Task NewInvoiceAsync()
    {
        var next = await ApiClient.Instance.NextInvoiceNoAsync();
        _index = -1; _isNew = true;
        InvoiceNoBox.Text = next; DatePickerBox.SelectedDate = DateTime.Today;
        CustomerCombo.SelectedIndex = -1; Lines.Clear();
        Lines.Add(new LineVm { Sno = 1, StockType = "Stock" });
        UpdateTotal(); SetEnabled(true); ErrorText.Text = "";
    }

    private void UpdateTotal() => TotalText.Text = $"Total: {Lines.Sum(l => l.Amount):N2}";

    private void First_Click(object sender, RoutedEventArgs e) => GoTo(0);
    private void Prev_Click(object sender, RoutedEventArgs e) => GoTo(_index - 1);
    private void Next_Click(object sender, RoutedEventArgs e) => GoTo(_index + 1);
    private void Last_Click(object sender, RoutedEventArgs e) => GoTo(_invoices.Count - 1);

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var t = SearchBox.Text;
        var found = _invoices.FindIndex(i => i.InvoiceNo.Contains(t));
        if (found >= 0) GoTo(found);
    }

    private void CustomerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // Address auto-fill omitted from the WPF view for brevity - see the Angular
        // InvoiceComponent (onCustomerChange) for the equivalent behavior.
    }

    private async void New_Click(object sender, RoutedEventArgs e) => await NewInvoiceAsync();
    private void Edit_Click(object sender, RoutedEventArgs e) { if (!string.IsNullOrEmpty(InvoiceNoBox.Text)) { _isNew = false; SetEnabled(true); } }
    private void AddLine_Click(object sender, RoutedEventArgs e) => Lines.Add(new LineVm { Sno = Lines.Count + 1, StockType = "Stock" });

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = "";
        var dto = new SalesDto(InvoiceNoBox.Text, DatePickerBox.SelectedDate ?? DateTime.Today,
            (string)CustomerCombo.SelectedValue, "",
            0, Lines.Select(l => l.ToDto(InvoiceNoBox.Text, DatePickerBox.SelectedDate ?? DateTime.Today)).ToList());

        var resp = _isNew
            ? await ApiClient.Instance.CreateInvoiceAsync(dto)
            : await ApiClient.Instance.UpdateInvoiceAsync(dto.InvoiceNo, dto);

        if (resp.IsSuccessStatusCode)
        {
            _invoices = await ApiClient.Instance.GetInvoicesAsync() ?? new();
            var idx = _invoices.FindIndex(i => i.InvoiceNo == dto.InvoiceNo);
            if (idx >= 0) GoTo(idx);
        }
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(InvoiceNoBox.Text) || _isNew) return;
        if (MessageBox.Show($"Delete invoice {InvoiceNoBox.Text}?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        var resp = await ApiClient.Instance.DeleteInvoiceAsync(InvoiceNoBox.Text);
        if (resp.IsSuccessStatusCode) { _invoices = await ApiClient.Instance.GetInvoicesAsync() ?? new(); if (_invoices.Count > 0) GoTo(0); else await NewInvoiceAsync(); }
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) { if (_index >= 0) GoTo(_index); SetEnabled(false); ErrorText.Text=""; }
}

// Lightweight grid row view-model - keeps DataGrid bindings simple.
public class LineVm
{
    public int Sno { get; set; }
    public string StockType { get; set; } = "Stock";
    public string StockCode { get; set; } = "";
    public decimal Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal Discount { get; set; }
    public decimal Amount => Math.Round(Quantity * Rate - Discount, 2);

    public static LineVm From(SalesDetailDto d) => new()
    {
        Sno = d.Sno, StockType = d.StockType, StockCode = d.StockCode,
        Quantity = d.Quantity, Rate = d.Rate, Discount = d.Discount
    };

    public SalesDetailDto ToDto(string invoiceNo, DateTime date) =>
        new(0, invoiceNo, date, Sno, StockCode, StockType, Quantity, Rate, Discount, Amount);
}
