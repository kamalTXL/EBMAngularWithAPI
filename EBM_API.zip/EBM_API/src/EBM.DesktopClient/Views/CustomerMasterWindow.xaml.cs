using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using EBM.DesktopClient.Models;
using EBM.DesktopClient.Services;

namespace EBM.DesktopClient.Views;

public partial class CustomerMasterWindow : Window
{
    private List<CustomerDto> _items = new();
    private List<CustomerDto> _filtered = new();
    private int _index = -1;
    private bool _isNew;

    public CustomerMasterWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await LoadAsync();
    }

    private async System.Threading.Tasks.Task LoadAsync()
    {
        AreaCombo.ItemsSource = await ApiClient.Instance.GetCustomerAreasAsync();
        CategoryCombo.ItemsSource = await ApiClient.Instance.GetCustomerCategoriesAsync();
        _items = await ApiClient.Instance.GetCustomersAsync() ?? new();
        _filtered = _items;
        if (_filtered.Count > 0) GoTo(0); else ClearForm();
    }

    private void SetEnabled(bool enabled)
    {
        NameBox.IsEnabled = enabled; AddressBox.IsEnabled = enabled;
        AreaCombo.IsEnabled = enabled; CategoryCombo.IsEnabled = enabled;
        CodeBox.IsEnabled = _isNew;
    }

    private void GoTo(int i)
    {
        if (i < 0 || i >= _filtered.Count) return;
        _index = i; _isNew = false;
        var c = _filtered[i];
        CodeBox.Text = c.Code; NameBox.Text = c.Name; AddressBox.Text = c.Address;
        AreaCombo.SelectedValue = c.AreaCode; CategoryCombo.SelectedValue = c.CategoryCode;
        SetEnabled(false); ErrorText.Text = "";
    }

    private void ClearForm()
    {
        _index = -1;
        CodeBox.Text = NameBox.Text = AddressBox.Text = "";
        AreaCombo.SelectedIndex = -1; CategoryCombo.SelectedIndex = -1;
    }

    private void First_Click(object sender, RoutedEventArgs e) => GoTo(0);
    private void Prev_Click(object sender, RoutedEventArgs e) => GoTo(_index - 1);
    private void Next_Click(object sender, RoutedEventArgs e) => GoTo(_index + 1);
    private void Last_Click(object sender, RoutedEventArgs e) => GoTo(_filtered.Count - 1);

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var t = SearchBox.Text.ToLowerInvariant();
        _filtered = _items.Where(c => c.Code.ToLowerInvariant().Contains(t) || c.Name.ToLowerInvariant().Contains(t)).ToList();
        if (_filtered.Count > 0) GoTo(0);
    }

    private void New_Click(object sender, RoutedEventArgs e) { ClearForm(); _isNew = true; SetEnabled(true); ErrorText.Text = ""; }
    private void Edit_Click(object sender, RoutedEventArgs e) { if (!string.IsNullOrEmpty(CodeBox.Text)) { _isNew = false; SetEnabled(true); } }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = "";
        var dto = new CustomerDto(CodeBox.Text, NameBox.Text, AddressBox.Text,
            (string)AreaCombo.SelectedValue, (string)CategoryCombo.SelectedValue);
        var resp = _isNew
            ? await ApiClient.Instance.CreateCustomerAsync(dto)
            : await ApiClient.Instance.UpdateCustomerAsync(dto.Code, dto);
        if (resp.IsSuccessStatusCode) await LoadAsync();
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(CodeBox.Text)) return;
        if (MessageBox.Show($"Delete customer {CodeBox.Text}?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        var resp = await ApiClient.Instance.DeleteCustomerAsync(CodeBox.Text);
        if (resp.IsSuccessStatusCode) await LoadAsync();
        else ErrorText.Text = await resp.Content.ReadAsStringAsync();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) { if (_index >= 0) GoTo(_index); else ClearForm(); SetEnabled(false); ErrorText.Text=""; }
}
