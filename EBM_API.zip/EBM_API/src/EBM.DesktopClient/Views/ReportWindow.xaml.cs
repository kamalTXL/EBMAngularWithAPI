using System;
using System.IO;
using System.Windows;
using EBM.DesktopClient.Models;
using EBM.DesktopClient.Services;
using Microsoft.Win32;

namespace EBM.DesktopClient.Views;

public partial class ReportWindow : Window
{
    private static readonly string[] Levels = { "Customer", "Area", "Product", "ProductCategory", "ProductBrand" };

    public ReportWindow()
    {
        InitializeComponent();
        Level1Combo.ItemsSource = Levels; Level1Combo.SelectedIndex = 2; // Product
        Level2Combo.ItemsSource = Levels;
        FromDate.SelectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        ToDate.SelectedDate = DateTime.Today;
    }

    private ReportFilterDto BuildFilter() => new(
        FromDate.SelectedDate ?? DateTime.Today.AddMonths(-1),
        ToDate.SelectedDate ?? DateTime.Today,
        Level1Combo.SelectedItem as string,
        Level2Combo.SelectedItem as string);

    private async void View_Click(object sender, RoutedEventArgs e)
    {
        var rows = await ApiClient.Instance.ViewReportAsync(BuildFilter());
        ResultsGrid.ItemsSource = rows;
    }

    private void Print_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new System.Windows.Controls.PrintDialog();
        if (dlg.ShowDialog() == true) dlg.PrintVisual(ResultsGrid, "EBM Sales Report");
    }

    private async void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        var bytes = await ApiClient.Instance.ExportExcelAsync(BuildFilter());
        var dlg = new SaveFileDialog { FileName = $"SalesReport_{DateTime.Now:yyyyMMddHHmmss}.xlsx", Filter = "Excel Workbook|*.xlsx" };
        if (dlg.ShowDialog() == true) File.WriteAllBytes(dlg.FileName, bytes);
    }
}
