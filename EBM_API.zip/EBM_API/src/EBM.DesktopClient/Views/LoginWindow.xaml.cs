using System.Windows;
using EBM.DesktopClient.Services;

namespace EBM.DesktopClient.Views;

public partial class LoginWindow : Window
{
    public LoginWindow() => InitializeComponent();

    private async void Submit_Click(object sender, RoutedEventArgs e)
    {
        if (AcceptCheck.IsChecked != true)
        {
            ErrorText.Text = "Please accept the disclaimer to continue.";
            return;
        }

        var result = await ApiClient.Instance.LoginAsync(UserNameBox.Text, PasswordBox.Password);
        if (result?.Success == true)
        {
            new MainShellWindow().Show();
            Close();
        }
        else
        {
            ErrorText.Text = result?.Message ?? "Invalid user name or password.";
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        UserNameBox.Text = string.Empty;
        PasswordBox.Password = string.Empty;
        AcceptCheck.IsChecked = false;
    }
}
