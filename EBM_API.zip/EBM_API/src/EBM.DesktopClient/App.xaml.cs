using System.Windows;

namespace EBM.DesktopClient;

public partial class App : Application { }
