using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

// Backs the "Invoice" transaction form: header (Invoice No/Date/Customer/Address) +
// an editable grid of lines (Stock/Non-Stock, Category, Brand, Expiry date, Image,
// Qty, Rate, Discount, Amount) with a running Total, per the wireframe.
[ApiController]
[Route("api/invoices")]
[Authorize]
public class InvoicesController : ControllerBase
{
    private readonly IInvoiceService _invoices;
    public InvoicesController(IInvoiceService invoices) => _invoices = invoices;

    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _invoices.GetAllAsync());

    [HttpGet("next-number")]
    public async Task<IActionResult> NextNumber() => Ok(new { invoiceNo = await _invoices.GetNextInvoiceNoAsync() });

    [HttpGet("{invoiceNo}")]
    public async Task<IActionResult> Get(string invoiceNo)
    {
        var s = await _invoices.GetByInvoiceNoAsync(invoiceNo);
        return s is null ? NotFound() : Ok(s);
    }

    [HttpPost]
    public async Task<IActionResult> Create(SalesDto dto)
    {
        try { return Ok(await _invoices.SaveAsync(dto, isNew: true)); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpPut("{invoiceNo}")]
    public async Task<IActionResult> Update(string invoiceNo, SalesDto dto)
    {
        try { return Ok(await _invoices.SaveAsync(dto with { InvoiceNo = invoiceNo }, isNew: false)); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpDelete("{invoiceNo}")]
    public async Task<IActionResult> Delete(string invoiceNo)
    {
        try { await _invoices.DeleteAsync(invoiceNo); return NoContent(); }
        catch (KeyNotFoundException) { return NotFound(); }
    }

    // Report screen has "Email To/Cc/Bcc/Subject/Body, attach report as PDF" for invoices too;
    // actual PDF+SMTP composition happens in EmailController to keep concerns separated.
}
