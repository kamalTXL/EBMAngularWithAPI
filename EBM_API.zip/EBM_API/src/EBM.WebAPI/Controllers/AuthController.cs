using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _auth;
    private readonly IWebHostEnvironment _env;

    public AuthController(IAuthService auth, IWebHostEnvironment env)
    {
        _auth = auth;
        _env = env;
    }

    // POST api/auth/login  - used by BOTH the Angular Login page and the WPF Login window
    [HttpPost("login")]
    public async Task<ActionResult<LoginResult>> Login(LoginRequest request)
    {
        var result = await _auth.LoginAsync(request);
        return result.Success ? Ok(result) : Unauthorized(result);
    }

    // POST api/auth/setup  - ONE-TIME bootstrap endpoint to create the very first login
    // user with a correctly hashed password (PBKDF2 + per-user salt), so you don't have
    // to write SQL by hand or guess AuthService's hashing scheme.
    //
    // Safety rails, so this can't be (ab)used once the app is live:
    //   1) only responds while ASPNETCORE_ENVIRONMENT=Development
    //   2) refuses once ANY user already exists in the Users table
    // Delete this action (or at least remove it before deploying) once you've created
    // your admin user - it is a deliberate, temporary hole in auth.
    [HttpPost("setup")]
    public async Task<IActionResult> Setup(LoginRequest request)
    {
        if (!_env.IsDevelopment())
            return NotFound();

        if (await _auth.AnyUsersExistAsync())
            return Conflict(new { message = "A user already exists - remove/disable this endpoint now." });
        
        if (string.IsNullOrWhiteSpace(request.UserName) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest(new { message = "UserName and Password are required." });

        await _auth.CreateUserAsync(request.UserName, request.Password);
        return Ok(new { message = $"User '{request.UserName}' created. Remove/disable POST api/auth/setup now." });
    }
}
