using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

[ApiController]
[Route("api/lookups")]
[Authorize]
public class LookupsController : ControllerBase
{
    private readonly IMasterDataService _master;
    public LookupsController(IMasterDataService master) => _master = master;

    [HttpGet("product-categories")]
    public async Task<IActionResult> ProductCategories() => Ok(await _master.GetProductCategoriesAsync());

    [HttpGet("product-brands")]
    public async Task<IActionResult> ProductBrands() => Ok(await _master.GetProductBrandsAsync());

    [HttpGet("customer-categories")]
    public async Task<IActionResult> CustomerCategories() => Ok(await _master.GetCustomerCategoriesAsync());

    [HttpGet("customer-areas")]
    public async Task<IActionResult> CustomerAreas() => Ok(await _master.GetCustomerAreasAsync());
}
