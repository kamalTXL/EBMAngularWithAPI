using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

// Backs the "Product Master" form (Code/Name/Category/Brand/Image/Sales Rate/Cost Rate,
// New/Edit/Delete/Save/Cancel, First/Prev/Next/Last navigation + Find/Search on the client).
[ApiController]
[Route("api/products")]
[Authorize]
public class ProductsController : ControllerBase
{
    private readonly IMasterDataService _master;
    public ProductsController(IMasterDataService master) => _master = master;

    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _master.GetProductsAsync());

    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code)
    {
        var p = await _master.GetProductAsync(code);
        return p is null ? NotFound() : Ok(p);
    }

    [HttpPost]
    public async Task<IActionResult> Create(ProductDto dto)
    {
        try { return Ok(await _master.SaveProductAsync(dto, isNew: true)); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpPut("{code}")]
    public async Task<IActionResult> Update(string code, ProductDto dto)
    {
        try { return Ok(await _master.SaveProductAsync(dto with { Code = code }, isNew: false)); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpDelete("{code}")]
    public async Task<IActionResult> Delete(string code)
    {
        try { await _master.DeleteProductAsync(code); return NoContent(); }
        catch (KeyNotFoundException) { return NotFound(); }
    }
}
