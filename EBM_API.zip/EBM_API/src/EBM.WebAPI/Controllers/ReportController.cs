using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

// Backs the "Report" screen (date range + up to 2 grouping levels, View / Export to Excel)
// and supplies the Dashboard's drag-and-drop X/Y axis chart data.
[ApiController]
[Route("api/report")]
[Authorize]
public class ReportController : ControllerBase
{
    private readonly IReportService _report;
    public ReportController(IReportService report) => _report = report;

    [HttpPost("view")]
    public async Task<IActionResult> View(ReportFilterDto filter) => Ok(await _report.GetSalesReportAsync(filter));

    [HttpPost("export-excel")]
    public async Task<IActionResult> ExportExcel(ReportFilterDto filter)
    {
        var bytes = await _report.ExportToExcelAsync(filter);
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"SalesReport_{DateTime.Now:yyyyMMddHHmmss}.xlsx");
    }

    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard([FromQuery] string xAxis = "ProductCategory", [FromQuery] string series = "Product")
        => Ok(await _report.GetDashboardDataAsync(xAxis, series));
}
