using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBM.WebAPI.Controllers;

// Backs the "Customer Master" form (Code/Name/Address/Area/Category, same
// New/Edit/Delete/Save/Cancel + navigation pattern as Product Master).
[ApiController]
[Route("api/customers")]
[Authorize]
public class CustomersController : ControllerBase
{
    private readonly IMasterDataService _master;
    public CustomersController(IMasterDataService master) => _master = master;

    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _master.GetCustomersAsync());

    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code)
    {
        var c = await _master.GetCustomerAsync(code);
        return c is null ? NotFound() : Ok(c);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CustomerDto dto)
    {
        try { return Ok(await _master.SaveCustomerAsync(dto, isNew: true)); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpPut("{code}")]
    public async Task<IActionResult> Update(string code, CustomerDto dto)
    {
        try { return Ok(await _master.SaveCustomerAsync(dto with { Code = code }, isNew: false)); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpDelete("{code}")]
    public async Task<IActionResult> Delete(string code)
    {
        try { await _master.DeleteCustomerAsync(code); return NoContent(); }
        catch (KeyNotFoundException) { return NotFound(); }
    }
}
