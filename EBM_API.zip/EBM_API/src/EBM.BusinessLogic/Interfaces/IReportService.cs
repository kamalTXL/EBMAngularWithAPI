using EBM.BusinessLogic.DTOs;

namespace EBM.BusinessLogic.Interfaces;

public interface IReportService
{
    Task<IReadOnlyList<ReportRowDto>> GetSalesReportAsync(ReportFilterDto filter);
    Task<byte[]> ExportToExcelAsync(ReportFilterDto filter);
    Task<IReadOnlyList<DashboardPointDto>> GetDashboardDataAsync(string xAxisField, string seriesField);
}
