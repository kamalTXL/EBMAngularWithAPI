using EBM.Domain.Entities;

namespace EBM.BusinessLogic.Interfaces;

public interface ITokenService
{
    string GenerateToken(User user);
}
