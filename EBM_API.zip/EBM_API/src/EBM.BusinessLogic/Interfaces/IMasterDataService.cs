using EBM.BusinessLogic.DTOs;

namespace EBM.BusinessLogic.Interfaces;

// Covers Product Master + Customer Master and their lookup (category/brand/area) tables
public interface IMasterDataService
{
    Task<IReadOnlyList<LookupDto>> GetProductCategoriesAsync();
    Task<IReadOnlyList<LookupDto>> GetProductBrandsAsync();
    Task<IReadOnlyList<LookupDto>> GetCustomerCategoriesAsync();
    Task<IReadOnlyList<LookupDto>> GetCustomerAreasAsync();

    Task<IReadOnlyList<ProductDto>> GetProductsAsync();
    Task<ProductDto?> GetProductAsync(string code);
    Task<ProductDto> SaveProductAsync(ProductDto dto, bool isNew);
    Task DeleteProductAsync(string code);

    Task<IReadOnlyList<CustomerDto>> GetCustomersAsync();
    Task<CustomerDto?> GetCustomerAsync(string code);
    Task<CustomerDto> SaveCustomerAsync(CustomerDto dto, bool isNew);
    Task DeleteCustomerAsync(string code);
}
