using EBM.BusinessLogic.DTOs;

namespace EBM.BusinessLogic.Interfaces;

public interface IAuthService
{
    Task<LoginResult> LoginAsync(LoginRequest request);
    Task CreateUserAsync(string userName, string password);
    Task<bool> AnyUsersExistAsync();
}
