using EBM.BusinessLogic.DTOs;

namespace EBM.BusinessLogic.Interfaces;

public interface IInvoiceService
{
    Task<IReadOnlyList<SalesDto>> GetAllAsync();
    Task<SalesDto?> GetByInvoiceNoAsync(string invoiceNo);
    Task<SalesDto> SaveAsync(SalesDto dto, bool isNew);
    Task DeleteAsync(string invoiceNo);
    Task<string> GetNextInvoiceNoAsync();
}
