using ClosedXML.Excel;
using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using EBM.DataAccess.Repositories;

namespace EBM.BusinessLogic.Services;

// Implements the "Report" screen from the spec: date-range filter, up to 2 grouping
// levels (Customer / Area / Product / Product Category / Product Brand), and
// View / Export-to-Excel. Also feeds the Dashboard's drag-drop X/Y axis chart.
public class ReportService : IReportService
{
    private readonly IUnitOfWork _uow;

    public ReportService(IUnitOfWork uow) => _uow = uow;

    public async Task<IReadOnlyList<ReportRowDto>> GetSalesReportAsync(ReportFilterDto filter)
    {
        var sales = (await _uow.Sales.FindAsync(s => s.Date >= filter.From && s.Date <= filter.To)).ToList();
        var invoiceNos = sales.Select(s => s.InvoiceNo).ToHashSet();
        var details = (await _uow.SalesDetails.GetAllAsync()).Where(d => invoiceNos.Contains(d.InvoiceNo)).ToList();
        var products = (await _uow.Products.GetAllAsync()).ToDictionary(p => p.Code);
        var customers = (await _uow.Customers.GetAllAsync()).ToDictionary(c => c.Code);
        var areas = (await _uow.CustomerAreas.GetAllAsync()).ToDictionary(a => a.Code);
        var categories = (await _uow.ProductCategories.GetAllAsync()).ToDictionary(c => c.Code);
        var brands = (await _uow.ProductBrands.GetAllAsync()).ToDictionary(b => b.Code);
        var salesByInvoice = sales.ToDictionary(s => s.InvoiceNo);

        string KeyFor(string level, EBM.Domain.Entities.SalesDetail d)
        {
            var sale = salesByInvoice[d.InvoiceNo];
            var customer = customers.GetValueOrDefault(sale.CustomerCode);
            var product = products.GetValueOrDefault(d.StockCode);
            return level switch
            {
                "Customer" => customer?.Name ?? sale.CustomerCode,
                "Area" => customer is null ? "-" : (areas.GetValueOrDefault(customer.AreaCode)?.Name ?? customer.AreaCode),
                "Product" => product?.Name ?? d.StockCode,
                "ProductCategory" => product is null ? "-" : (categories.GetValueOrDefault(product.CategoryCode)?.Name ?? product.CategoryCode),
                "ProductBrand" => product is null ? "-" : (brands.GetValueOrDefault(product.BrandCode)?.Name ?? product.BrandCode),
                _ => "All"
            };
        }

        var level1 = string.IsNullOrWhiteSpace(filter.Level1) ? "Product" : filter.Level1!;
        var level2 = filter.Level2;

        var grouped = details
            .GroupBy(d => new { G1 = KeyFor(level1, d), G2 = level2 is null ? null : KeyFor(level2, d) })
            .Select(g => new ReportRowDto(
                g.Key.G1, g.Key.G1, g.Key.G2, g.Key.G2,
                g.Sum(x => x.Quantity), g.Sum(x => x.Amount)))
            .OrderBy(r => r.GroupLabel).ThenBy(r => r.SubGroupLabel)
            .ToList();

        return grouped;
    }

    public async Task<byte[]> ExportToExcelAsync(ReportFilterDto filter)
    {
        var rows = await GetSalesReportAsync(filter);

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Sales Report");
        ws.Cell(1, 1).Value = "EBM Company";
        ws.Cell(2, 1).Value = "Sales Report";
        ws.Cell(1, 4).Value = "From";
        ws.Cell(1, 5).Value = filter.From.ToString("dd/MM/yyyy");
        ws.Cell(2, 4).Value = "To";
        ws.Cell(2, 5).Value = filter.To.ToString("dd/MM/yyyy");

        var headerRow = 4;
        ws.Cell(headerRow, 1).Value = "Group";
        ws.Cell(headerRow, 2).Value = "Sub-Group";
        ws.Cell(headerRow, 3).Value = "Quantity";
        ws.Cell(headerRow, 4).Value = "Amount";
        ws.Range(headerRow, 1, headerRow, 4).Style.Font.Bold = true;

        var r = headerRow + 1;
        decimal totalQty = 0, totalAmt = 0;
        foreach (var row in rows)
        {
            ws.Cell(r, 1).Value = row.GroupLabel;
            ws.Cell(r, 2).Value = row.SubGroupLabel ?? "";
            ws.Cell(r, 3).Value = row.Quantity;
            ws.Cell(r, 4).Value = row.Amount;
            totalQty += row.Quantity;
            totalAmt += row.Amount;
            r++;
        }
        ws.Cell(r, 1).Value = "Grand Total";
        //ws.Cell(r, 1, r, 2).Merge().Style.Font.Bold = true;
        ws.Cell(r, 3).Value = totalQty;
        ws.Cell(r, 4).Value = totalAmt;
        ws.Range(r, 3, r, 4).Style.Font.Bold = true;
        ws.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    public async Task<IReadOnlyList<DashboardPointDto>> GetDashboardDataAsync(string xAxisField, string seriesField)
    {
        // Powers the Dashboard's drag-and-drop chart (spec: "dynamically select X and Y
        // axis by drag and drop" from Item Groups, Customer Groups, Items, Customers, Periods).
        var filter = new ReportFilterDto(DateTime.MinValue, DateTime.MaxValue, xAxisField, seriesField);
        var rows = await GetSalesReportAsync(filter);
        return rows.Select(r => new DashboardPointDto(r.GroupLabel, r.SubGroupLabel ?? r.GroupLabel, r.Amount)).ToList();
    }
}
