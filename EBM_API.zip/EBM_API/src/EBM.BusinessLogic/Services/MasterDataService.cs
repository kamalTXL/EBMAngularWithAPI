using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using EBM.DataAccess.Repositories;
using EBM.Domain.Entities;

namespace EBM.BusinessLogic.Services;

public class MasterDataService : IMasterDataService
{
    private readonly IUnitOfWork _uow;

    public MasterDataService(IUnitOfWork uow) => _uow = uow;

    public async Task<IReadOnlyList<LookupDto>> GetProductCategoriesAsync() =>
        (await _uow.ProductCategories.GetAllAsync()).Select(x => new LookupDto(x.Code, x.Name)).ToList();

    public async Task<IReadOnlyList<LookupDto>> GetProductBrandsAsync() =>
        (await _uow.ProductBrands.GetAllAsync()).Select(x => new LookupDto(x.Code, x.Name)).ToList();

    public async Task<IReadOnlyList<LookupDto>> GetCustomerCategoriesAsync() =>
        (await _uow.CustomerCategories.GetAllAsync()).Select(x => new LookupDto(x.Code, x.Name)).ToList();

    public async Task<IReadOnlyList<LookupDto>> GetCustomerAreasAsync() =>
        (await _uow.CustomerAreas.GetAllAsync()).Select(x => new LookupDto(x.Code, x.Name)).ToList();

    // ---------- Product Master ----------

    public async Task<IReadOnlyList<ProductDto>> GetProductsAsync() =>
        (await _uow.Products.GetAllAsync()).Select(ToDto).ToList();

    public async Task<ProductDto?> GetProductAsync(string code)
    {
        var p = await _uow.Products.GetByIdAsync(code);
        return p is null ? null : ToDto(p);
    }

    public async Task<ProductDto> SaveProductAsync(ProductDto dto, bool isNew)
    {
        Validate(dto);

        if (isNew)
        {
            if (await _uow.Products.GetByIdAsync(dto.Code) is not null)
                throw new InvalidOperationException($"Product code '{dto.Code}' already exists.");

            await _uow.Products.AddAsync(new Product
            {
                Code = dto.Code, Name = dto.Name, CategoryCode = dto.CategoryCode,
                BrandCode = dto.BrandCode, ImagePath = dto.ImagePath,
                SalesRate = dto.SalesRate, CostRate = dto.CostRate
            });
        }
        else
        {
            var existing = await _uow.Products.GetByIdAsync(dto.Code) ?? throw new KeyNotFoundException($"Product '{dto.Code}' not found.");
            existing.Name = dto.Name;
            existing.CategoryCode = dto.CategoryCode;
            existing.BrandCode = dto.BrandCode;
            existing.ImagePath = dto.ImagePath;
            existing.SalesRate = dto.SalesRate;
            existing.CostRate = dto.CostRate;
            _uow.Products.Update(existing);
        }

        await _uow.SaveChangesAsync();
        return dto;
    }

    public async Task DeleteProductAsync(string code)
    {
        var existing = await _uow.Products.GetByIdAsync(code)
            ?? throw new KeyNotFoundException($"Product '{code}' not found.");
        _uow.Products.Remove(existing);
        await _uow.SaveChangesAsync();
    }

    private static void Validate(ProductDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Code)) throw new ArgumentException("Product code is required.");
        if (string.IsNullOrWhiteSpace(dto.Name)) throw new ArgumentException("Product name is required.");
        if (dto.SalesRate < 0 || dto.CostRate < 0) throw new ArgumentException("Rates cannot be negative.");
    }

    private static ProductDto ToDto(Product p) =>
        new(p.Code, p.Name, p.CategoryCode, p.BrandCode, p.ImagePath, p.SalesRate, p.CostRate);

    // ---------- Customer Master ----------

    public async Task<IReadOnlyList<CustomerDto>> GetCustomersAsync() =>
        (await _uow.Customers.GetAllAsync()).Select(ToDto).ToList();

    public async Task<CustomerDto?> GetCustomerAsync(string code)
    {
        var c = await _uow.Customers.GetByIdAsync(code);
        return c is null ? null : ToDto(c);
    }

    public async Task<CustomerDto> SaveCustomerAsync(CustomerDto dto, bool isNew)
    {
        if (string.IsNullOrWhiteSpace(dto.Code)) throw new ArgumentException("Customer code is required.");
        if (string.IsNullOrWhiteSpace(dto.Name)) throw new ArgumentException("Customer name is required.");

        if (isNew)
        {
            if (await _uow.Customers.GetByIdAsync(dto.Code) is not null)
                throw new InvalidOperationException($"Customer code '{dto.Code}' already exists.");

            await _uow.Customers.AddAsync(new Customer
            {
                Code = dto.Code, Name = dto.Name, Address = dto.Address,
                AreaCode = dto.AreaCode, CategoryCode = dto.CategoryCode
            });
        }
        else
        {
            var existing = await _uow.Customers.GetByIdAsync(dto.Code)
                ?? throw new KeyNotFoundException($"Customer '{dto.Code}' not found.");
            existing.Name = dto.Name;
            existing.Address = dto.Address;
            existing.AreaCode = dto.AreaCode;
            existing.CategoryCode = dto.CategoryCode;
            _uow.Customers.Update(existing);
        }

        await _uow.SaveChangesAsync();
        return dto;
    }

    public async Task DeleteCustomerAsync(string code)
    {
        var existing = await _uow.Customers.GetByIdAsync(code)
            ?? throw new KeyNotFoundException($"Customer '{code}' not found.");
        _uow.Customers.Remove(existing);
        await _uow.SaveChangesAsync();
    }

    private static CustomerDto ToDto(Customer c) =>
        new(c.Code, c.Name, c.Address, c.AreaCode, c.CategoryCode);
}
