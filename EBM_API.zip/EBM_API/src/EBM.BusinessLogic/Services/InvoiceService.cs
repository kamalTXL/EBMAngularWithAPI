using EBM.BusinessLogic.DTOs;
using EBM.BusinessLogic.Interfaces;
using EBM.DataAccess.Repositories;
using EBM.Domain.Entities;

namespace EBM.BusinessLogic.Services;

// Encapsulates ALL invoice business rules (line totals, header total, next invoice
// numbering) so that neither front end has to duplicate this logic - both the Angular
// web client and the WPF desktop client call the same Web API endpoints that sit on
// top of this service.
public class InvoiceService : IInvoiceService
{
    private readonly IUnitOfWork _uow;

    public InvoiceService(IUnitOfWork uow) => _uow = uow;

    public async Task<IReadOnlyList<SalesDto>> GetAllAsync() =>
        (await _uow.Sales.GetAllAsync()).Select(s => ToDto(s, null)).ToList();

    public async Task<SalesDto?> GetByInvoiceNoAsync(string invoiceNo)
    {
        var sale = await _uow.Sales.GetByIdAsync(invoiceNo);
        if (sale is null) return null;
        var details = await _uow.SalesDetails.FindAsync(d => d.InvoiceNo == invoiceNo);
        return ToDto(sale, details.OrderBy(d => d.Sno).ToList());
    }

    public async Task<string> GetNextInvoiceNoAsync()
    {
        var all = await _uow.Sales.GetAllAsync();
        var max = all.Select(s => int.TryParse(s.InvoiceNo, out var n) ? n : 0).DefaultIfEmpty(0).Max();
        return (max + 1).ToString().PadLeft(6, '0');
    }

    public async Task<SalesDto> SaveAsync(SalesDto dto, bool isNew)
    {
        if (string.IsNullOrWhiteSpace(dto.InvoiceNo)) throw new ArgumentException("Invoice number is required.");
        if (string.IsNullOrWhiteSpace(dto.CustomerCode)) throw new ArgumentException("Customer is required.");
        if (dto.Details is null || dto.Details.Count == 0) throw new ArgumentException("At least one line item is required.");

        // Recompute every line amount and the grand total server-side - never trust the client total.
        var recalculated = dto.Details.Select((d, idx) =>
        {
            var amount = Math.Round((d.Quantity * d.Rate) - d.Discount, 3);
            return d with { Sno = idx + 1, Amount = amount };
        }).ToList();
        var total = recalculated.Sum(d => d.Amount);

        if (isNew)
        {
            if (await _uow.Sales.GetByIdAsync(dto.InvoiceNo) is not null)
                throw new InvalidOperationException($"Invoice '{dto.InvoiceNo}' already exists.");

            var sale = new Sales
            {
                InvoiceNo = dto.InvoiceNo, Date = dto.Date, CustomerCode = dto.CustomerCode,
                Address = dto.Address, Total = total
            };
            await _uow.Sales.AddAsync(sale);

            foreach (var d in recalculated)
                await _uow.SalesDetails.AddAsync(ToEntity(d, dto.InvoiceNo, dto.Date));
        }
        else
        {
            var sale = await _uow.Sales.GetByIdAsync(dto.InvoiceNo)
                ?? throw new KeyNotFoundException($"Invoice '{dto.InvoiceNo}' not found.");
            sale.Date = dto.Date;
            sale.CustomerCode = dto.CustomerCode;
            sale.Address = dto.Address;
            sale.Total = total;
            _uow.Sales.Update(sale);

            var existingDetails = await _uow.SalesDetails.FindAsync(d => d.InvoiceNo == dto.InvoiceNo);
            foreach (var d in existingDetails) _uow.SalesDetails.Remove(d);
            foreach (var d in recalculated)
                await _uow.SalesDetails.AddAsync(ToEntity(d, dto.InvoiceNo, dto.Date));
        }

        await _uow.SaveChangesAsync();
        return dto with { Details = recalculated, Total = total };
    }

    public async Task DeleteAsync(string invoiceNo)
    {
        var sale = await _uow.Sales.GetByIdAsync(invoiceNo)
            ?? throw new KeyNotFoundException($"Invoice '{invoiceNo}' not found.");
        _uow.Sales.Remove(sale); // SalesDetail rows cascade-delete per DbContext configuration
        await _uow.SaveChangesAsync();
    }

    private static SalesDetail ToEntity(SalesDetailDto d, string invoiceNo, DateTime date) =>
        new()
        {
            InvoiceNo = invoiceNo, Date = date, Sno = d.Sno, StockCode = d.StockCode,
            StockType = Enum.Parse<StockType>(d.StockType, ignoreCase: true),
            Quantity = d.Quantity, Rate = d.Rate, Discount = d.Discount, Amount = d.Amount
        };

    private static SalesDto ToDto(Sales s, IReadOnlyList<SalesDetail>? details) => new(
        s.InvoiceNo, s.Date, s.CustomerCode, s.Address, s.Total,
        (details ?? Array.Empty<SalesDetail>()).Select(d => new SalesDetailDto(
            d.Id, d.InvoiceNo, d.Date, d.Sno, d.StockCode, d.StockType.ToString(),
            d.Quantity, d.Rate, d.Discount, d.Amount)).ToList());
}

