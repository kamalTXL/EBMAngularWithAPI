// Electron main process for the EBM Test Project desktop shell.
//
// This is intentionally thin: it does NOT talk to SQL Server, EF Core, or
// EBM.BusinessLogic directly. It just opens a native window pointed at the same
// Angular UI (EBM.WebClient) that runs in a browser, which in turn calls the same
// EBM.WebAPI backend over HTTPS - identical business logic, identical API, just a
// different shell around the same front-end code.
const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

const isDev = process.env.EBM_DEV === 'true';

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 480,          // Angular layout is responsive down to phone widths too
    minHeight: 640,
    title: 'EBM Test Project',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  Menu.setApplicationMenu(null);

  if (isDev) {
    // Dev mode: point at `ng serve` (run `npm start` in EBM.WebClient first)
    win.loadURL('http://localhost:4200');
    win.webContents.openDevTools({ mode: 'detach' });
  } else {
    // Packaged mode: load the built Angular output directly - no separate server needed.
    win.loadFile(path.join(__dirname, '..', 'EBM.WebClient', 'dist', 'ebm-web-client', 'index.html'));
  }
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
