// No privileged Node APIs are exposed to the renderer - the Angular app only ever
// needs plain HTTPS calls to EBM.WebAPI, which it already does via HttpClient.
// This file exists as the sanctioned place to add contextBridge APIs later
// (e.g. native file save dialogs for Excel export) without turning on nodeIntegration.
