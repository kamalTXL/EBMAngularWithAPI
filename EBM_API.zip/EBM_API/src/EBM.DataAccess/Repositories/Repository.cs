using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;

namespace EBM.DataAccess.Repositories;

public class Repository<TEntity, TKey> : IRepository<TEntity, TKey> where TEntity : class
{
    protected readonly EBMDbContext Context;
    protected readonly DbSet<TEntity> Set;

    public Repository(EBMDbContext context)
    {
        Context = context;
        Set = context.Set<TEntity>();
    }

    public async Task<TEntity?> GetByIdAsync(TKey id) => await Set.FindAsync(id);

    public async Task<IReadOnlyList<TEntity>> GetAllAsync() => await Set.AsNoTracking().ToListAsync();

    public async Task<IReadOnlyList<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate) =>
        await Set.AsNoTracking().Where(predicate).ToListAsync();

    public async Task AddAsync(TEntity entity) => await Set.AddAsync(entity);

    public void Update(TEntity entity) => Set.Update(entity);

    public void Remove(TEntity entity) => Set.Remove(entity);
}
