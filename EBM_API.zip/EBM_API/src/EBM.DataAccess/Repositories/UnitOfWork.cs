using EBM.Domain.Entities;

namespace EBM.DataAccess.Repositories;

public class UnitOfWork : IUnitOfWork
{
    private readonly EBMDbContext _context;

    public UnitOfWork(EBMDbContext context)
    {
        _context = context;
        Users = new Repository<User, int>(_context);
        ProductCategories = new Repository<ProductCategory, string>(_context);
        ProductBrands = new Repository<ProductBrand, string>(_context);
        Products = new Repository<Product, string>(_context);
        CustomerCategories = new Repository<CustomerCategory, string>(_context);
        CustomerAreas = new Repository<CustomerArea, string>(_context);
        Customers = new Repository<Customer, string>(_context);
        Sales = new Repository<Sales, string>(_context);
        SalesDetails = new Repository<SalesDetail, int>(_context);
    }

    public IRepository<User, int> Users { get; }
    public IRepository<ProductCategory, string> ProductCategories { get; }
    public IRepository<ProductBrand, string> ProductBrands { get; }
    public IRepository<Product, string> Products { get; }
    public IRepository<CustomerCategory, string> CustomerCategories { get; }
    public IRepository<CustomerArea, string> CustomerAreas { get; }
    public IRepository<Customer, string> Customers { get; }
    public IRepository<Sales, string> Sales { get; }
    public IRepository<SalesDetail, int> SalesDetails { get; }

    public Task<int> SaveChangesAsync() => _context.SaveChangesAsync();
}
