using EBM.Domain.Entities;

namespace EBM.DataAccess.Repositories;

public interface IUnitOfWork
{
    IRepository<User, int> Users { get; }
    IRepository<ProductCategory, string> ProductCategories { get; }
    IRepository<ProductBrand, string> ProductBrands { get; }
    IRepository<Product, string> Products { get; }
    IRepository<CustomerCategory, string> CustomerCategories { get; }
    IRepository<CustomerArea, string> CustomerAreas { get; }
    IRepository<Customer, string> Customers { get; }
    IRepository<Sales, string> Sales { get; }
    IRepository<SalesDetail, int> SalesDetails { get; }

    Task<int> SaveChangesAsync();
}
