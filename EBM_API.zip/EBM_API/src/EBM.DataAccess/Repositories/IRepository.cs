using System.Linq.Expressions;

namespace EBM.DataAccess.Repositories;

// Generic repository - keeps EF Core (and therefore the Data layer) fully hidden
// from the Business Logic layer, which only ever talks to these interfaces.
public interface IRepository<TEntity, TKey> where TEntity : class
{
    Task<TEntity?> GetByIdAsync(TKey id);
    Task<IReadOnlyList<TEntity>> GetAllAsync();
    Task<IReadOnlyList<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate);
    Task AddAsync(TEntity entity);
    void Update(TEntity entity);
    void Remove(TEntity entity);
}
