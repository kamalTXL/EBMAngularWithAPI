using EBM.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EBM.DataAccess;

// This DbContext is the ONLY place that talks to SQL Server (via EF Core ORM as required
// by the spec). It is consumed exclusively by EBM.BusinessLogic - never directly by any
// front end - which keeps the 3-tier separation (UI | Business Logic | Data) intact.
public class EBMDbContext : DbContext
{
    public EBMDbContext(DbContextOptions<EBMDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<ProductCategory> ProductCategories => Set<ProductCategory>();
    public DbSet<ProductBrand> ProductBrands => Set<ProductBrand>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<CustomerCategory> CustomerCategories => Set<CustomerCategory>();
    public DbSet<CustomerArea> CustomerAreas => Set<CustomerArea>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Sales> Sales => Set<Sales>();
    public DbSet<SalesDetail> SalesDetails => Set<SalesDetail>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
            e.HasIndex(x => x.Name).IsUnique();
            e.Property(x => x.PasswordHash).HasMaxLength(255).IsRequired();
            e.Property(x => x.PasswordSalt).HasMaxLength(255).IsRequired();
        });

        b.Entity<ProductCategory>(e =>
        {
            e.ToTable("ProductCategory");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
        });

        b.Entity<ProductBrand>(e =>
        {
            e.ToTable("ProductBrand");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
        });

        b.Entity<Product>(e =>
        {
            e.ToTable("Product");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
            e.Property(x => x.CategoryCode).HasMaxLength(10).IsRequired();
            e.Property(x => x.BrandCode).HasMaxLength(10).IsRequired();
            e.Property(x => x.ImagePath).HasMaxLength(255);
            e.Property(x => x.SalesRate).HasColumnType("decimal(12,3)");
            e.Property(x => x.CostRate).HasColumnType("decimal(12,3)");

            e.HasOne(x => x.Category).WithMany(c => c.Products)
                .HasForeignKey(x => x.CategoryCode).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Brand).WithMany(c => c.Products)
                .HasForeignKey(x => x.BrandCode).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<CustomerCategory>(e =>
        {
            e.ToTable("CustomerCategory");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
        });

        b.Entity<CustomerArea>(e =>
        {
            e.ToTable("CustomerArea");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
        });

        b.Entity<Customer>(e =>
        {
            e.ToTable("Customer");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
            e.Property(x => x.Address).HasMaxLength(255);
            e.Property(x => x.AreaCode).HasMaxLength(10).IsRequired();
            e.Property(x => x.CategoryCode).HasMaxLength(10).IsRequired();

            e.HasOne(x => x.Area).WithMany(a => a.Customers)
                .HasForeignKey(x => x.AreaCode).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Category).WithMany(c => c.Customers)
                .HasForeignKey(x => x.CategoryCode).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<Sales>(e =>
        {
            e.ToTable("Sales");
            e.HasKey(x => x.InvoiceNo);
            e.Property(x => x.InvoiceNo).HasMaxLength(10);
            e.Property(x => x.CustomerCode).HasMaxLength(10).IsRequired();
            e.Property(x => x.Address).HasMaxLength(255);
            e.Property(x => x.Total).HasColumnType("decimal(20,3)");

            e.HasOne(x => x.Customer).WithMany()
                .HasForeignKey(x => x.CustomerCode).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<SalesDetail>(e =>
        {
            e.ToTable("SalesDetail");
            e.HasKey(x => x.Id);
            e.Property(x => x.InvoiceNo).HasMaxLength(10).IsRequired();
            e.Property(x => x.StockCode).HasMaxLength(10).IsRequired();
            e.Property(x => x.Quantity).HasColumnType("decimal(12,3)");
            e.Property(x => x.Rate).HasColumnType("decimal(12,3)");
            e.Property(x => x.Discount).HasColumnType("decimal(12,3)");
            e.Property(x => x.Amount).HasColumnType("decimal(20,3)");
            e.Property(x => x.StockType).HasConversion<string>().HasMaxLength(10);

            e.HasOne(x => x.Sales).WithMany(s => s.Details)
                .HasForeignKey(x => x.InvoiceNo).OnDelete(DeleteBehavior.Cascade);

            e.HasIndex(x => new { x.InvoiceNo, x.Sno }).IsUnique();
        });
    }
}
