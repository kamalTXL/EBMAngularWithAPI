namespace EBM.Domain.Entities;

public class SalesDetail
{
    public int Id { get; set; }                          // surrogate PK (InvoiceNo+Sno is the natural key)
    public string InvoiceNo { get; set; } = string.Empty; // FK -> Sales
    public DateTime Date { get; set; }
    public int Sno { get; set; }
    public string StockCode { get; set; } = string.Empty; // Product.Code when StockType = Stock
    public StockType StockType { get; set; }
    public decimal Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal Discount { get; set; }
    public decimal Amount { get; set; }

    public Sales? Sales { get; set; }
}
