namespace EBM.Domain.Entities;

public class ProductCategory
{
    public string Code { get; set; } = string.Empty; // PK, max 10
    public string Name { get; set; } = string.Empty; // max 50
    public ICollection<Product> Products { get; set; } = new List<Product>();
}
