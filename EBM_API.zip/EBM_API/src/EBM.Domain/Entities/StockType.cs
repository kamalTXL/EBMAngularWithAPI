namespace EBM.Domain.Entities;

// "Stock" / "Non-Stock" radio option on the Invoice grid per the spec
public enum StockType
{
    Stock = 0,
    NonStock = 1
}
