namespace EBM.Domain.Entities;

public class Customer
{
    public string Code { get; set; } = string.Empty;   // PK
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string AreaCode { get; set; } = string.Empty;     // FK -> CustomerArea
    public string CategoryCode { get; set; } = string.Empty; // FK -> CustomerCategory

    public CustomerArea? Area { get; set; }
    public CustomerCategory? Category { get; set; }
}
