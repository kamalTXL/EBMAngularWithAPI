namespace EBM.Domain.Entities;

public class Product
{
    public string Code { get; set; } = string.Empty;        // PK
    public string Name { get; set; } = string.Empty;
    public string CategoryCode { get; set; } = string.Empty; // FK -> ProductCategory
    public string BrandCode { get; set; } = string.Empty;    // FK -> ProductBrand
    public string? ImagePath { get; set; }
    public decimal SalesRate { get; set; }
    public decimal CostRate { get; set; }

    public ProductCategory? Category { get; set; }
    public ProductBrand? Brand { get; set; }
}
