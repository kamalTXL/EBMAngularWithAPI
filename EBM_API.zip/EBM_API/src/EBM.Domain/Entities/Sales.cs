namespace EBM.Domain.Entities;

public class Sales
{
    public string InvoiceNo { get; set; } = string.Empty; // PK
    public DateTime Date { get; set; }
    public string CustomerCode { get; set; } = string.Empty; // FK -> Customer
    public string Address { get; set; } = string.Empty;
    public decimal Total { get; set; }

    public Customer? Customer { get; set; }
    public ICollection<SalesDetail> Details { get; set; } = new List<SalesDetail>();
}
